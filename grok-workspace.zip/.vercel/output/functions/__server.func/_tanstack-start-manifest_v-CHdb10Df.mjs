//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CHdb10Df.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/pages/$pageId",
			"/rooms/$roomId",
			"/pages/",
			"/rooms/"
		],
		preloads: [
			"/assets/index-QwjqLXEs.js",
			"/assets/dialogs-BYYFBNIy.js",
			"/assets/preload-helper-DZ_kPqsG.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-QwjqLXEs.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-C3OdkkAW.js",
			"/assets/useNavigate-CGNpfKPm.js",
			"/assets/cards-rZNg76yn.js"
		]
	},
	"/pages/$pageId": {
		filePath: "/workspace/src/routes/pages/$pageId.tsx",
		children: void 0,
		preloads: [
			"/assets/_pageId-ClPh7kbo.js",
			"/assets/useNavigate-CGNpfKPm.js",
			"/assets/chevron-left-PsdWZX7E.js"
		]
	},
	"/rooms/$roomId": {
		filePath: "/workspace/src/routes/rooms/$roomId.tsx",
		children: void 0,
		preloads: [
			"/assets/_roomId-G7F9fB9m.js",
			"/assets/useNavigate-CGNpfKPm.js",
			"/assets/chevron-left-PsdWZX7E.js"
		]
	},
	"/pages/": {
		filePath: "/workspace/src/routes/pages/index.tsx",
		children: void 0,
		preloads: ["/assets/pages-Et8A_bIW.js", "/assets/cards-rZNg76yn.js"]
	},
	"/rooms/": {
		filePath: "/workspace/src/routes/rooms/index.tsx",
		children: void 0,
		preloads: ["/assets/rooms-DGsgZuU3.js", "/assets/cards-rZNg76yn.js"]
	}
} });
//#endregion
export { tsrStartManifest };
