import { i as __toESM } from "./_runtime.mjs";
import { n as require_react } from "./_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as Link, x as useNavigate } from "./_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "./_libs/radix-ui__react-context+react.mjs";
import { c as ChevronLeft, s as ExternalLink } from "./_libs/lucide-react.mjs";
import { C as relativeDay, D as EmptyState, E as Button, a as ConfirmDialog, h as useLedger, l as PLATFORMS, o as PageDialog, r as Route$2, s as PostDialog, u as PLATFORM_MARK, w as todayISO, x as isUrl } from "./_ssr/router-UWfdBrAR.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_pageId-C3f8kqyP.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PageDetail() {
	const { pageId } = Route$2.useParams();
	const navigate = useNavigate();
	const page = useLedger((state) => state.pages.find((item) => item.id === pageId));
	const rooms = useLedger((state) => state.rooms);
	const posts = useLedger((state) => state.posts.filter((post) => post.pageId === pageId).sort((a, b) => b.postedAt.localeCompare(a.postedAt)));
	const setPostStatus = useLedger((state) => state.setPostStatus);
	const deletePage = useLedger((state) => state.deletePage);
	const [edit, setEdit] = (0, import_react.useState)(false);
	const [log, setLog] = (0, import_react.useState)(false);
	const [remove, setRemove] = (0, import_react.useState)(false);
	const today = todayISO();
	if (!page) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
		title: "Không thấy trang này",
		body: "Có thể trang đã bị xóa khỏi sổ.",
		action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/pages",
			className: "inline-flex min-h-11 items-center rounded-full bg-lacquer px-4 text-sm font-medium text-lacquer-ink",
			children: "Về danh sách"
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-3xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/pages",
				className: "inline-flex min-h-11 items-center gap-1 text-sm font-medium text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, {
					className: "size-4",
					"aria-hidden": true
				}), "Trang"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex items-start gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "grid size-12 shrink-0 place-items-center rounded-2xl bg-lacquer text-sm font-semibold text-lacquer-ink",
					children: PLATFORM_MARK[page.platform]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: PLATFORMS[page.platform]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-3xl break-words",
						children: page.name
					})]
				})]
			}),
			page.note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-muted",
				children: page.note
			}) : null,
			page.url && isUrl(page.url) ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
				href: page.url,
				target: "_blank",
				rel: "noreferrer",
				className: "mt-3 inline-flex min-h-11 items-center gap-2 text-sm font-medium text-lacquer",
				children: ["Mở trang", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, {
					className: "size-4",
					"aria-hidden": true
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-5",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => setLog(true),
					children: "Ghi phòng đã đăng"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-3 font-display text-2xl",
					children: "Phòng đã đăng ở đây"
				}), posts.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "rounded-2xl bg-surface px-4 py-4 text-sm text-muted shadow-card",
					children: "Chưa ghi lần đăng nào lên trang này."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "rounded-2xl bg-surface px-4 shadow-card",
					children: posts.map((post) => {
						const room = rooms.find((item) => item.id === post.roomId);
						if (!room) return null;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center justify-between gap-3 border-b border-line py-3 last:border-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/rooms/$roomId",
								params: { roomId: room.id },
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block truncate font-medium",
									children: room.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "block text-sm text-muted",
									children: [
										room.district,
										" · ",
										relativeDay(post.postedAt, today)
									]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								size: "sm",
								className: "shrink-0",
								onClick: () => setPostStatus(post.id, post.status === "live" ? "removed" : "live"),
								children: post.status === "live" ? "Gỡ bài" : "Hiện lại"
							})]
						}, post.id);
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "quiet",
					onClick: () => setEdit(true),
					children: "Sửa trang"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					onClick: () => setRemove(true),
					children: "Xóa"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageDialog, {
				open: edit,
				onOpenChange: setEdit,
				page
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PostDialog, {
				open: log,
				onOpenChange: setLog,
				pageId: page.id
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: remove,
				onOpenChange: setRemove,
				title: "Xóa trang này?",
				body: "Các lần đăng gắn với trang cũng bị xóa. Phòng trong sổ vẫn còn.",
				confirmLabel: "Xóa trang",
				onConfirm: () => {
					deletePage(page.id);
					navigate({ to: "/pages" });
				}
			})
		]
	});
}
//#endregion
export { PageDetail as component };
