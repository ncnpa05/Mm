import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { A as cn, D as EmptyState, E as Button, S as monthKey, b as formatVnd, c as RoomDialog, g as fold, h as useLedger, s as PostDialog, w as todayISO } from "./router-UWfdBrAR.mjs";
import { n as RoomCard } from "./cards-C-aaxjvl.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/rooms-CjRr-2Pm.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var CHIPS = [
	{
		id: "all",
		label: "Tất cả"
	},
	{
		id: "selling",
		label: "Còn sale"
	},
	{
		id: "closed",
		label: "Đã chốt"
	}
];
function RoomsPage() {
	const rooms = useLedger((state) => state.rooms);
	const posts = useLedger((state) => state.posts);
	const filter = useLedger((state) => state.roomFilter);
	const setRoomFilter = useLedger((state) => state.setRoomFilter);
	const [query, setQuery] = (0, import_react.useState)("");
	const [roomOpen, setRoomOpen] = (0, import_react.useState)(false);
	const [logRoom, setLogRoom] = (0, import_react.useState)(null);
	const today = todayISO();
	const month = monthKey(today);
	const filtered = (0, import_react.useMemo)(() => {
		const needle = fold(query.trim());
		return rooms.filter((room) => {
			if (filter === "selling" && room.status === "closed") return false;
			if (filter === "closed" && room.status !== "closed") return false;
			if (!needle) return true;
			return fold(`${room.name} ${room.district} ${room.address} ${room.landlordName} ${room.landlordPhone}`).includes(needle);
		}).sort((a, b) => {
			if (filter === "closed") return (b.closedAt ?? "").localeCompare(a.closedAt ?? "");
			return b.createdAt.localeCompare(a.createdAt);
		});
	}, [
		rooms,
		filter,
		query
	]);
	const closed = rooms.filter((room) => room.status === "closed");
	const monthSum = closed.filter((room) => room.closedAt && monthKey(room.closedAt) === month).reduce((sum, room) => sum + (room.commission ?? 0), 0);
	const allSum = closed.reduce((sum, room) => sum + (room.commission ?? 0), 0);
	const counts = {
		all: rooms.length,
		selling: rooms.filter((room) => room.status !== "closed").length,
		closed: closed.length
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-end justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl md:text-4xl",
				children: "Phòng"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: "Phòng đang sale và phòng đã chốt."
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: () => setRoomOpen(true),
				children: "Thêm phòng"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			className: "mt-4 min-h-11 w-full rounded-xl bg-surface px-3 text-base shadow-card outline-none placeholder:text-muted",
			value: query,
			onChange: (event) => setQuery(event.target.value),
			placeholder: "Tìm phòng, quận, chủ nhà…",
			"aria-label": "Tìm phòng"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-3 flex flex-wrap gap-2",
			children: CHIPS.map((chip) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				"aria-pressed": filter === chip.id,
				onClick: () => setRoomFilter(chip.id),
				className: cn("min-h-11 rounded-full px-4 text-sm font-medium", filter === chip.id ? "bg-lacquer text-lacquer-ink" : "bg-surface text-ink shadow-card"),
				children: [
					chip.label,
					" · ",
					counts[chip.id]
				]
			}, chip.id))
		}),
		filter === "closed" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 rounded-2xl bg-moss-soft px-4 py-4 text-moss",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium",
					children: "Tổng hoa hồng đã chốt"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 font-display text-3xl tabular-nums",
					children: formatVnd(allSum)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-sm",
					children: ["Tháng này ", formatVnd(monthSum)]
				})
			]
		}) : null,
		rooms.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				title: "Chưa có phòng",
				body: "Thêm căn đang cần sale. Khi khách lấy phòng, bấm chốt để ghi hoa hồng.",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => setRoomOpen(true),
					children: "Thêm phòng đầu tiên"
				})
			})
		}) : filtered.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-6 rounded-2xl bg-surface px-4 py-4 text-sm text-muted shadow-card",
			children: "Không có phòng khớp."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-4 grid gap-3 md:grid-cols-2",
			children: filtered.map((room) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoomCard, {
				room,
				liveCount: posts.filter((post) => post.roomId === room.id && post.status === "live").length,
				onLog: () => setLogRoom(room.id)
			}, room.id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoomDialog, {
			open: roomOpen,
			onOpenChange: setRoomOpen
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PostDialog, {
			open: logRoom !== null,
			onOpenChange: (open) => {
				if (!open) setLogRoom(null);
			},
			roomId: logRoom ?? void 0
		})
	] });
}
//#endregion
export { RoomsPage as component };
