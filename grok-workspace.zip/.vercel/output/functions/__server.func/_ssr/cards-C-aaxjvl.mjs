import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { E as Button, T as Badge, b as formatVnd, d as ROOM_STATUS, f as ROOM_TYPES, l as PLATFORMS, u as PLATFORM_MARK, y as formatShort } from "./router-UWfdBrAR.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/cards-C-aaxjvl.js
var import_jsx_runtime = require_jsx_runtime();
function statusTone(status) {
	if (status === "closed") return "moss";
	if (status === "viewing") return "ink";
	if (status === "posted") return "muted";
	return "lacquer";
}
function RoomCard({ room, liveCount, onLog }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "flex flex-col rounded-2xl bg-surface p-4 shadow-card transition-shadow duration-200 hover:shadow-card-hover",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
					tone: statusTone(room.status),
					children: ROOM_STATUS[room.status]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "shrink-0 font-display text-xl tabular-nums",
					children: formatVnd(room.price)
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/rooms/$roomId",
				params: { roomId: room.id },
				className: "mt-3 block min-w-0 flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-lg font-semibold break-words",
					children: room.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-sm text-muted",
					children: [
						room.district,
						" · ",
						ROOM_TYPES[room.type],
						room.areaM2 ? ` · ${room.areaM2}m²` : ""
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "min-w-0 text-sm text-muted",
					children: room.status === "closed" ? `Chốt ${room.closedAt ? formatShort(room.closedAt) : ""} · ${formatVnd(room.commission ?? 0)}` : liveCount ? `${liveCount} trang đang hiện` : "Chưa đăng trang nào"
				}), room.status !== "closed" && onLog ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "quiet",
					size: "sm",
					onClick: onLog,
					className: "shrink-0",
					children: "Ghi đã đăng"
				}) : null]
			})
		]
	});
}
function PageCard({ page, postCount, lastPosted }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/pages/$pageId",
		params: { pageId: page.id },
		className: "block rounded-2xl bg-surface p-4 shadow-card transition-shadow duration-200 hover:shadow-card-hover",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "grid size-11 shrink-0 place-items-center rounded-2xl bg-paper text-sm font-semibold",
				children: PLATFORM_MARK[page.platform]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "min-w-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block truncate font-semibold",
					children: page.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "block text-sm text-muted",
					children: [
						PLATFORMS[page.platform],
						" · ",
						postCount,
						" bài",
						lastPosted ? ` · ${formatShort(lastPosted)}` : ""
					]
				})]
			})]
		})
	});
}
//#endregion
export { RoomCard as n, PageCard as t };
