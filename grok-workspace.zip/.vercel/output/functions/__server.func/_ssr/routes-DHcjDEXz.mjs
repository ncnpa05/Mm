import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as Link, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { C as relativeDay, D as EmptyState, E as Button, S as monthKey, T as Badge, _ as formatDay, b as formatVnd, c as RoomDialog, h as useLedger, m as needsRepost, s as PostDialog, v as formatMonth, w as todayISO } from "./router-UWfdBrAR.mjs";
import { n as RoomCard } from "./cards-C-aaxjvl.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DHcjDEXz.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	const rooms = useLedger((state) => state.rooms);
	const pages = useLedger((state) => state.pages);
	const posts = useLedger((state) => state.posts);
	const setRoomFilter = useLedger((state) => state.setRoomFilter);
	const loadDemo = useLedger((state) => state.loadDemo);
	const navigate = useNavigate();
	const today = todayISO();
	const month = monthKey(today);
	const [roomOpen, setRoomOpen] = (0, import_react.useState)(false);
	const [log, setLog] = (0, import_react.useState)({ open: false });
	const selling = rooms.filter((room) => room.status !== "closed");
	const closedMonth = rooms.filter((room) => room.status === "closed" && room.closedAt && monthKey(room.closedAt) === month).sort((a, b) => (b.closedAt ?? "").localeCompare(a.closedAt ?? ""));
	const commission = closedMonth.reduce((sum, room) => sum + (room.commission ?? 0), 0);
	const postsToday = posts.filter((post) => post.postedAt === today).length;
	const attention = rooms.filter((room) => needsRepost(room, posts, today)).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
	const recent = [...posts].sort((a, b) => b.postedAt.localeCompare(a.postedAt) || b.id.localeCompare(a.id)).slice(0, 5);
	if (rooms.length === 0 && pages.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-3xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium text-muted",
				children: "Hôm nay"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl md:text-4xl",
				children: formatDay(today)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
					title: "Sổ còn trống",
					body: "Thêm phòng đang sale, ghi trang đã đăng, rồi chốt khi khách lấy phòng.",
					action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => setRoomOpen(true),
						children: "Thêm phòng"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "quiet",
						onClick: loadDemo,
						children: "Xem sổ mẫu"
					})] })
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoomDialog, {
				open: roomOpen,
				onOpenChange: setRoomOpen
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-3xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm font-medium text-muted",
				children: ["Hôm nay · ", formatMonth()]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-1 font-display text-3xl md:text-4xl",
				children: formatDay(today)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-6 rounded-3xl bg-lacquer px-5 py-5 text-lacquer-ink",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium",
						children: "Hoa hồng tháng này"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 font-display text-4xl tabular-nums leading-none",
						children: formatVnd(commission)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm",
						children: closedMonth.length ? `${closedMonth.length} phòng đã chốt` : "Chưa chốt phòng nào trong tháng"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-3 rounded-3xl bg-surface px-4 shadow-card",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LedgerRow, {
						label: "Còn sale",
						value: String(selling.length)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LedgerRow, {
						label: "Đã chốt tháng này",
						value: String(closedMonth.length)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LedgerRow, {
						label: "Bài đăng hôm nay",
						value: String(postsToday)
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => setLog({ open: true }),
					children: "Ghi bài đăng"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "quiet",
					onClick: () => setRoomOpen(true),
					children: "Thêm phòng"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
					title: "Nên đăng hôm nay",
					action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/rooms",
						className: "inline-flex min-h-11 items-center text-sm font-medium text-lacquer",
						onClick: () => setRoomFilter("selling"),
						children: "Phòng còn sale"
					})
				}), attention.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "rounded-2xl bg-surface px-4 py-4 text-sm text-muted shadow-card",
					children: "Các phòng đang sale đều đã được đăng trong 2 ngày qua."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-3",
					children: attention.map((room) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoomCard, {
						room,
						liveCount: posts.filter((post) => post.roomId === room.id && post.status === "live").length,
						onLog: () => setLog({
							open: true,
							roomId: room.id
						})
					}, room.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
					title: "Đã chốt tháng này",
					action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "inline-flex min-h-11 items-center text-sm font-medium text-lacquer",
						onClick: () => {
							setRoomFilter("closed");
							navigate({ to: "/rooms" });
						},
						children: "Xem hết"
					})
				}), closedMonth.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "rounded-2xl bg-surface px-4 py-4 text-sm text-muted shadow-card",
					children: "Tháng này chưa có phòng nào chốt."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "rounded-2xl bg-surface px-4 shadow-card",
					children: closedMonth.map((room) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "border-b border-line last:border-0",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/rooms/$roomId",
							params: { roomId: room.id },
							className: "flex min-h-16 items-center justify-between gap-3 py-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block truncate font-medium",
									children: room.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "block text-sm text-muted",
									children: [room.district, room.closeNote ? ` · ${room.closeNote}` : ""]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "shrink-0 text-right",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block font-display text-xl tabular-nums text-moss",
									children: formatVnd(room.commission ?? 0)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-sm text-muted",
									children: room.closedAt ? relativeDay(room.closedAt, today) : ""
								})]
							})]
						})
					}, room.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
					title: "Bài vừa đăng",
					action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/pages",
						className: "inline-flex min-h-11 items-center text-sm font-medium text-lacquer",
						children: "Các trang"
					})
				}), recent.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "rounded-2xl bg-surface px-4 py-4 text-sm text-muted shadow-card",
					children: "Chưa ghi bài đăng nào."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "rounded-2xl bg-surface px-4 shadow-card",
					children: recent.map((post) => {
						const room = rooms.find((item) => item.id === post.roomId);
						const page = pages.find((item) => item.id === post.pageId);
						if (!room || !page) return null;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "border-b border-line last:border-0",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/pages/$pageId",
								params: { pageId: page.id },
								className: "flex min-h-16 items-center justify-between gap-3 py-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block truncate font-medium",
										children: room.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "block truncate text-sm text-muted",
										children: [
											page.name,
											" · ",
											relativeDay(post.postedAt, today)
										]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									tone: post.status === "live" ? "lacquer" : "muted",
									children: post.status === "live" ? "Đang hiện" : "Đã gỡ"
								})]
							})
						}, post.id);
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoomDialog, {
				open: roomOpen,
				onOpenChange: setRoomOpen
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PostDialog, {
				open: log.open,
				onOpenChange: (open) => setLog((current) => ({
					...current,
					open
				})),
				roomId: log.roomId
			})
		]
	});
}
function LedgerRow({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center justify-between gap-3 border-b border-line py-3 last:border-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-2xl tabular-nums",
			children: value
		})]
	});
}
function SectionTitle({ title, action }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-3 flex flex-wrap items-end justify-between gap-x-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-2xl",
			children: title
		}), action]
	});
}
//#endregion
export { Home as component };
