import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { S as useRouter, _ as lazyRouteComponent, b as Link, d as Scripts, f as HeadContent, g as Outlet, h as createRouter, p as useRouterState, v as createFileRoute, y as createRootRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { i as Megaphone, l as Check, n as TriangleAlert, o as KeyRound, t as X, u as CalendarDays } from "../_libs/lucide-react.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { a as DialogOverlay, i as DialogDescription, n as DialogClose, o as DialogPortal, r as DialogContent, s as DialogTitle, t as Dialog } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-UWfdBrAR.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* Path-based preview hosts serve the dev server under `/{port_id}/` and strip
* that prefix before forwarding, so SSR sees `/` while the browser URL keeps the
* prefix. TanStack Start resets `basepath` on hydration, so a `rewrite` keeps
* client routing and generated links aligned with the public URL.
*/
var PATH_BASED_PREVIEW_HOSTS = /* @__PURE__ */ new Set([
	"preview.grok.genai.mil",
	"preview.grok.mil",
	"preview.grokgsac.com"
]);
var PORT_ID_PREFIX = /^\/hds-[a-z0-9]+-\d+-[a-z0-9]+(?=\/|$)/i;
function previewPathPrefix(hostname, pathname) {
	if (!PATH_BASED_PREVIEW_HOSTS.has(hostname.toLowerCase())) return void 0;
	return PORT_ID_PREFIX.exec(pathname)?.[0];
}
function prefixRewrite(prefix) {
	return {
		input: ({ url }) => {
			if (url.pathname === prefix) url.pathname = "/";
			else if (url.pathname.startsWith(`${prefix}/`)) url.pathname = url.pathname.slice(prefix.length);
			return url;
		},
		output: ({ url }) => {
			url.pathname = `${prefix}${url.pathname}`;
			return url;
		}
	};
}
function previewPathRewrite() {
	if (typeof window === "undefined") return void 0;
	const prefix = previewPathPrefix(window.location.hostname, window.location.pathname);
	return prefix ? prefixRewrite(prefix) : void 0;
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var fieldClass = "min-h-11 w-full rounded-xl bg-paper px-3 text-base text-ink shadow-card outline-none placeholder:text-muted";
var buttonClass = cva("inline-flex items-center justify-center gap-2 rounded-full font-medium transition-colors duration-200 disabled:cursor-not-allowed disabled:opacity-50", {
	variants: {
		variant: {
			primary: "bg-lacquer text-lacquer-ink",
			quiet: "bg-surface text-ink shadow-card",
			ghost: "bg-transparent text-ink"
		},
		size: {
			md: "min-h-11 px-4 text-sm",
			sm: "min-h-11 px-3 text-sm"
		}
	},
	defaultVariants: {
		variant: "primary",
		size: "md"
	}
});
function Button({ className, variant, size, type = "button", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type,
		className: cn(buttonClass({
			variant,
			size
		}), className),
		...props
	});
}
var badgeClass = cva("inline-flex items-center rounded-full px-2.5 py-1 text-xs font-semibold", { variants: { tone: {
	lacquer: "bg-lacquer-soft text-lacquer",
	moss: "bg-moss-soft text-moss",
	ink: "bg-paper text-ink",
	muted: "bg-paper text-muted"
} } });
function Badge({ tone, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: badgeClass({ tone }),
		children
	});
}
function Field({ label, error, hint, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mb-1.5 block text-sm font-medium",
				children: label
			}),
			children,
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mt-1 block text-sm text-lacquer",
				children: error
			}) : hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mt-1 block text-sm text-muted",
				children: hint
			}) : null
		]
	});
}
function Modal({ open, onOpenChange, title, description, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "fixed inset-0 z-40 bg-ink/40" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "sheet fixed inset-x-0 bottom-0 z-50 overflow-y-auto rounded-t-3xl bg-surface shadow-card focus:outline-none md:inset-x-auto md:bottom-auto md:left-1/2 md:top-1/2 md:-translate-x-1/2 md:-translate-y-1/2 md:rounded-3xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto mb-4 h-1 w-10 rounded-full bg-line md:hidden",
					"aria-hidden": true
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-4 flex items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
						className: "font-display text-2xl",
						children: title
					}), description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
						className: "mt-1 text-sm text-muted",
						children: description
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
						className: "sr-only",
						children: title
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogClose, {
						"aria-label": "Đóng",
						className: "grid size-11 shrink-0 place-items-center rounded-full text-muted",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
					})]
				}),
				children
			]
		})] })
	});
}
function EmptyState({ title, body, action }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-3xl bg-surface px-5 py-10 text-center shadow-card",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mx-auto mt-2 max-w-sm text-muted",
				children: body
			}),
			action ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-5 flex flex-wrap justify-center gap-2",
				children: action
			}) : null
		]
	});
}
function todayISO(now = /* @__PURE__ */ new Date()) {
	return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;
}
function shiftISO(days, now = /* @__PURE__ */ new Date()) {
	const next = new Date(now);
	next.setDate(next.getDate() + days);
	return todayISO(next);
}
function monthKey(iso) {
	return iso.slice(0, 7);
}
function daysSince(iso, today = todayISO()) {
	const [y, m, d] = iso.slice(0, 10).split("-").map(Number);
	const [ty, tm, td] = today.slice(0, 10).split("-").map(Number);
	if (!y || !m || !d || !ty || !tm || !td) return 0;
	const a = Date.UTC(y, m - 1, d);
	const b = Date.UTC(ty, tm - 1, td);
	return Math.round((b - a) / 864e5);
}
function cap(text) {
	return text ? text.charAt(0).toUpperCase() + text.slice(1) : text;
}
function formatDay(iso) {
	const [y, m, d] = iso.slice(0, 10).split("-").map(Number);
	if (!y || !m || !d) return iso;
	return cap(new Intl.DateTimeFormat("vi-VN", {
		weekday: "long",
		day: "numeric",
		month: "long"
	}).format(new Date(y, m - 1, d)));
}
function formatShort(iso) {
	const [y, m, d] = iso.slice(0, 10).split("-").map(Number);
	if (!y || !m || !d) return iso;
	return new Intl.DateTimeFormat("vi-VN", {
		day: "numeric",
		month: "short"
	}).format(new Date(y, m - 1, d));
}
function formatMonth(now = /* @__PURE__ */ new Date()) {
	return cap(new Intl.DateTimeFormat("vi-VN", {
		month: "long",
		year: "numeric"
	}).format(now));
}
function relativeDay(iso, today = todayISO()) {
	const days = daysSince(iso, today);
	if (days === 0) return "Hôm nay";
	if (days === 1) return "Hôm qua";
	if (days > 1 && days < 7) return `${days} ngày trước`;
	return formatShort(iso);
}
function formatVnd(amount) {
	if (!Number.isFinite(amount) || amount === 0) return "0đ";
	if (amount < 1e6) return `${Math.round(amount).toLocaleString("vi-VN")}đ`;
	const rounded = Math.round(amount / 1e6 * 10) / 10;
	return `${rounded.toLocaleString("vi-VN", {
		minimumFractionDigits: Number.isInteger(rounded) ? 0 : 1,
		maximumFractionDigits: 1
	})} triệu`;
}
function trieuInput(vnd) {
	if (vnd == null || vnd === 0) return "";
	return (Math.round(vnd / 1e6 * 10) / 10).toLocaleString("vi-VN", { maximumFractionDigits: 1 });
}
function fold(value) {
	return value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/đ/g, "d").replace(/Đ/g, "d").toLowerCase();
}
function isUrl(value) {
	return /^https?:\/\//i.test(value.trim());
}
var ROOM_STATUS = {
	open: "Còn sale",
	posted: "Đã đăng",
	viewing: "Đang xem",
	closed: "Đã chốt"
};
var ROOM_TYPES = {
	tro: "Phòng trọ",
	ccmn: "CCMN",
	studio: "Studio",
	house: "Nguyên căn",
	shop: "Mặt bằng"
};
var PLATFORMS = {
	facebook: "Facebook",
	zalo: "Zalo",
	chotot: "Chợ Tốt",
	tiktok: "TikTok",
	other: "Khác"
};
var PLATFORM_MARK = {
	facebook: "Fb",
	zalo: "Zl",
	chotot: "CT",
	tiktok: "Tk",
	other: "Kh"
};
var AMENITIES = [
	"Máy lạnh",
	"Gác lửng",
	"WC riêng",
	"Ban công",
	"Thang máy",
	"Chỗ để xe",
	"Nội thất",
	"Giờ giấc tự do"
];
function uid() {
	return crypto.randomUUID();
}
function buildDemo() {
	return {
		rooms: [
			{
				id: "r-bachi",
				name: "Gác 20m² gần chợ Bà Chiểu",
				district: "Bình Thạnh",
				address: "214/12 Xô Viết Nghệ Tĩnh",
				price: 32e5,
				type: "tro",
				areaM2: 20,
				amenities: [
					"Máy lạnh",
					"Gác lửng",
					"WC riêng",
					"Chỗ để xe"
				],
				landlordName: "Chị Hạnh",
				landlordPhone: "0903 112 458",
				status: "posted",
				commission: null,
				closedAt: null,
				closeNote: "",
				notes: "Điện 3,8k, nước 100k/người, cọc 1 tháng.",
				createdAt: `${shiftISO(-8)}T02:00:00.000Z`
			},
			{
				id: "r-q7",
				name: "CCMN full nội thất Lô A",
				district: "Quận 7",
				address: "88 Nguyễn Lương Bằng",
				price: 55e5,
				type: "ccmn",
				areaM2: 25,
				amenities: [
					"Máy lạnh",
					"Thang máy",
					"Nội thất",
					"Ban công"
				],
				landlordName: "Anh Khoa",
				landlordPhone: "0918 334 220",
				status: "viewing",
				commission: null,
				closedAt: null,
				closeNote: "",
				notes: "Khách nữ hẹn xem. Nội thất giữ nguyên.",
				createdAt: `${shiftISO(-6)}T02:00:00.000Z`
			},
			{
				id: "r-thao",
				name: "Studio ban công Thảo Điền",
				district: "Thủ Đức",
				address: "12 Quốc Hương",
				price: 68e5,
				type: "studio",
				areaM2: 28,
				amenities: [
					"Máy lạnh",
					"Ban công",
					"Nội thất",
					"Thang máy"
				],
				landlordName: "Cô Mai",
				landlordPhone: "0988 221 903",
				status: "closed",
				commission: 15e5,
				closedAt: shiftISO(-2),
				closeNote: "Khách couple, vào cuối tháng",
				notes: "Hoa hồng một tháng tiền phòng.",
				createdAt: `${shiftISO(-12)}T02:00:00.000Z`
			},
			{
				id: "r-govap",
				name: "Phòng không gác hẻm 45",
				district: "Gò Vấp",
				address: "45/8 Quang Trung",
				price: 24e5,
				type: "tro",
				areaM2: 16,
				amenities: [
					"WC riêng",
					"Chỗ để xe",
					"Giờ giấc tự do"
				],
				landlordName: "Chú Tư",
				landlordPhone: "0933 778 641",
				status: "open",
				commission: null,
				closedAt: null,
				closeNote: "",
				notes: "Không nuôi thú. Điện nước theo đồng hồ.",
				createdAt: `${shiftISO(-1)}T02:00:00.000Z`
			},
			{
				id: "r-tanbinh",
				name: "Nguyên căn 2 phòng ngủ",
				district: "Tân Bình",
				address: "19 Hoàng Văn Thụ",
				price: 85e5,
				type: "house",
				areaM2: 48,
				amenities: [
					"Máy lạnh",
					"Chỗ để xe",
					"WC riêng"
				],
				landlordName: "Anh Dũng",
				landlordPhone: "0908 556 172",
				status: "closed",
				commission: 2e6,
				closedAt: shiftISO(-25),
				closeNote: "Gia đình 3 người, cọc 2 tháng",
				notes: "Hẻm xe hơi.",
				createdAt: `${shiftISO(-40)}T02:00:00.000Z`
			},
			{
				id: "r-q10",
				name: "Mặt bằng mặt tiền nhỏ",
				district: "Quận 10",
				address: "102 Sư Vạn Hạnh",
				price: 12e6,
				type: "shop",
				areaM2: 30,
				amenities: ["WC riêng", "Chỗ để xe"],
				landlordName: "Chị Lan",
				landlordPhone: "0977 410 225",
				status: "posted",
				commission: null,
				closedAt: null,
				closeNote: "",
				notes: "Hợp quán nước, không karaoke.",
				createdAt: `${shiftISO(-5)}T02:00:00.000Z`
			}
		],
		pages: [
			{
				id: "p-fb-bt",
				name: "Hội phòng trọ Bình Thạnh",
				platform: "facebook",
				url: "",
				note: "Nhóm kín, đăng buổi sáng dễ có inbox.",
				createdAt: `${shiftISO(-20)}T02:00:00.000Z`
			},
			{
				id: "p-fb-sg",
				name: "Nhà trọ Sài Gòn giá rẻ",
				platform: "facebook",
				url: "",
				note: "Nhóm lớn, nhớ kèm giá và quận ở dòng đầu.",
				createdAt: `${shiftISO(-18)}T02:00:00.000Z`
			},
			{
				id: "p-chotot",
				name: "Chợ Tốt — Phòng trọ",
				platform: "chotot",
				url: "https://www.chotot.com",
				note: "",
				createdAt: `${shiftISO(-15)}T02:00:00.000Z`
			},
			{
				id: "p-zalo",
				name: "Zalo khu Gò Vấp",
				platform: "zalo",
				url: "",
				note: "Nhóm chủ nhà quanh Quang Trung.",
				createdAt: `${shiftISO(-9)}T02:00:00.000Z`
			},
			{
				id: "p-tiktok",
				name: "TikTok review phòng",
				platform: "tiktok",
				url: "",
				note: "Quay cửa và gác, gắn quận trong caption.",
				createdAt: `${shiftISO(-7)}T02:00:00.000Z`
			}
		],
		posts: [
			{
				id: "post-1",
				roomId: "r-bachi",
				pageId: "p-fb-bt",
				postedAt: todayISO(),
				note: "Đăng lúc sáng",
				status: "live"
			},
			{
				id: "post-2",
				roomId: "r-bachi",
				pageId: "p-fb-sg",
				postedAt: todayISO(),
				note: "",
				status: "live"
			},
			{
				id: "post-3",
				roomId: "r-q7",
				pageId: "p-fb-sg",
				postedAt: shiftISO(-1),
				note: "Kèm 4 ảnh",
				status: "live"
			},
			{
				id: "post-4",
				roomId: "r-q7",
				pageId: "p-chotot",
				postedAt: shiftISO(-1),
				note: "",
				status: "live"
			},
			{
				id: "post-5",
				roomId: "r-thao",
				pageId: "p-fb-sg",
				postedAt: shiftISO(-6),
				note: "",
				status: "removed"
			},
			{
				id: "post-6",
				roomId: "r-thao",
				pageId: "p-tiktok",
				postedAt: shiftISO(-5),
				note: "",
				status: "removed"
			},
			{
				id: "post-7",
				roomId: "r-tanbinh",
				pageId: "p-fb-bt",
				postedAt: shiftISO(-28),
				note: "",
				status: "removed"
			},
			{
				id: "post-8",
				roomId: "r-q10",
				pageId: "p-fb-sg",
				postedAt: shiftISO(-4),
				note: "",
				status: "live"
			},
			{
				id: "post-9",
				roomId: "r-q10",
				pageId: "p-chotot",
				postedAt: shiftISO(-4),
				note: "",
				status: "live"
			}
		],
		demo: true
	};
}
function listingText(room) {
	const lines = [`CHO THUÊ — ${room.name}`, `Khu vực: ${room.district}`];
	if (room.address) lines.push(`Địa chỉ: ${room.address}`);
	lines.push(`Giá: ${formatVnd(room.price)}/tháng`);
	lines.push(`Loại: ${ROOM_TYPES[room.type]}${room.areaM2 ? ` · ${room.areaM2}m²` : ""}`);
	if (room.amenities.length) lines.push(`Tiện ích: ${room.amenities.join(", ")}`);
	if (room.notes) lines.push(room.notes);
	if (room.landlordPhone) {
		const who = room.landlordName ? `${room.landlordName} — ` : "";
		lines.push(`Liên hệ: ${who}${room.landlordPhone}`);
	}
	return lines.join("\n");
}
function needsRepost(room, posts, today = todayISO()) {
	if (room.status === "closed") return false;
	const live = posts.filter((post) => post.roomId === room.id && post.status === "live");
	if (live.length === 0) return true;
	const [y, m, d] = live.reduce((max, post) => post.postedAt > max ? post.postedAt : max, "").slice(0, 10).split("-").map(Number);
	const [ty, tm, td] = today.split("-").map(Number);
	if (!y || !m || !d || !ty || !tm || !td) return true;
	return Math.round((Date.UTC(ty, tm - 1, td) - Date.UTC(y, m - 1, d)) / 864e5) >= 2;
}
var emptyData = {
	rooms: [],
	pages: [],
	posts: [],
	demo: false
};
var useLedger = create()(persist((set) => ({
	...buildDemo(),
	roomFilter: "all",
	addRoom: (input) => {
		const id = uid();
		const room = {
			...input,
			id,
			status: "open",
			commission: null,
			closedAt: null,
			closeNote: "",
			createdAt: (/* @__PURE__ */ new Date()).toISOString()
		};
		set((state) => ({ rooms: [room, ...state.rooms] }));
		return id;
	},
	updateRoom: (id, input) => set((state) => ({ rooms: state.rooms.map((room) => room.id === id ? {
		...room,
		...input
	} : room) })),
	deleteRoom: (id) => set((state) => ({
		rooms: state.rooms.filter((room) => room.id !== id),
		posts: state.posts.filter((post) => post.roomId !== id)
	})),
	setStatus: (id, status) => set((state) => ({ rooms: state.rooms.map((room) => room.id === id ? {
		...room,
		status,
		commission: null,
		closedAt: null,
		closeNote: ""
	} : room) })),
	closeRoom: (id, info) => set((state) => ({
		rooms: state.rooms.map((room) => room.id === id ? {
			...room,
			status: "closed",
			commission: info.commission,
			closedAt: info.closedAt,
			closeNote: info.closeNote
		} : room),
		posts: info.removePosts ? state.posts.map((post) => post.roomId === id ? {
			...post,
			status: "removed"
		} : post) : state.posts
	})),
	reopenRoom: (id) => set((state) => ({ rooms: state.rooms.map((room) => room.id === id ? {
		...room,
		status: "open",
		commission: null,
		closedAt: null,
		closeNote: ""
	} : room) })),
	addPage: (input) => {
		const id = uid();
		const page = {
			...input,
			id,
			createdAt: (/* @__PURE__ */ new Date()).toISOString()
		};
		set((state) => ({ pages: [page, ...state.pages] }));
		return id;
	},
	updatePage: (id, input) => set((state) => ({ pages: state.pages.map((page) => page.id === id ? {
		...page,
		...input
	} : page) })),
	deletePage: (id) => set((state) => ({
		pages: state.pages.filter((page) => page.id !== id),
		posts: state.posts.filter((post) => post.pageId !== id)
	})),
	logPosts: (input) => set((state) => {
		const posts = state.posts.map((post) => ({ ...post }));
		for (const roomId of input.roomIds) for (const pageId of input.pageIds) {
			const existing = posts.find((post) => post.roomId === roomId && post.pageId === pageId && post.postedAt === input.postedAt);
			if (existing) {
				existing.note = input.note || existing.note;
				existing.status = "live";
			} else posts.push({
				id: uid(),
				roomId,
				pageId,
				postedAt: input.postedAt,
				note: input.note,
				status: "live"
			});
		}
		const chosen = new Set(input.roomIds);
		return {
			posts,
			rooms: state.rooms.map((room) => chosen.has(room.id) && room.status === "open" ? {
				...room,
				status: "posted"
			} : room)
		};
	}),
	setPostStatus: (id, status) => set((state) => ({ posts: state.posts.map((post) => post.id === id ? {
		...post,
		status
	} : post) })),
	setRoomFilter: (roomFilter) => set({ roomFilter }),
	clearAll: () => set(emptyData),
	loadDemo: () => set(buildDemo())
}), {
	name: "so-sale-v1",
	skipHydration: true,
	storage: createJSONStorage(() => localStorage),
	partialize: (state) => ({
		rooms: state.rooms,
		pages: state.pages,
		posts: state.posts,
		demo: state.demo
	})
}));
function readTrieu(raw, required) {
	if (!raw.trim()) return required ? {
		ok: false,
		error: "Nhập số tiền, đơn vị triệu. Ví dụ 3,2."
	} : {
		ok: true,
		value: 0
	};
	const value = Number(raw.trim().replace(/\s/g, "").replace(",", "."));
	if (!Number.isFinite(value) || value < 0 || required && value === 0) return {
		ok: false,
		error: "Số tiền chưa đúng."
	};
	if (value > 500) return {
		ok: false,
		error: "Nhập theo triệu. Ví dụ 3,2 chứ không phải 3200000."
	};
	return {
		ok: true,
		value: Math.round(value * 1e6)
	};
}
function readArea(raw) {
	if (!raw.trim()) return {
		ok: true,
		value: null
	};
	const value = Number(raw.trim().replace(",", "."));
	if (!Number.isFinite(value) || value <= 0 || value > 1e3) return {
		ok: false,
		error: "Diện tích chưa đúng."
	};
	return {
		ok: true,
		value: Math.round(value)
	};
}
function ConfirmDialog({ open, onOpenChange, title, body, confirmLabel, onConfirm }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
		open,
		onOpenChange,
		title,
		description: body,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-2 gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "quiet",
				onClick: () => onOpenChange(false),
				children: "Hủy"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: () => {
					onConfirm();
					onOpenChange(false);
				},
				children: confirmLabel
			})]
		})
	});
}
function RoomDialog({ open, onOpenChange, room, onSaved }) {
	const addRoom = useLedger((state) => state.addRoom);
	const updateRoom = useLedger((state) => state.updateRoom);
	const [name, setName] = (0, import_react.useState)("");
	const [district, setDistrict] = (0, import_react.useState)("");
	const [address, setAddress] = (0, import_react.useState)("");
	const [price, setPrice] = (0, import_react.useState)("");
	const [type, setType] = (0, import_react.useState)("tro");
	const [area, setArea] = (0, import_react.useState)("");
	const [amenities, setAmenities] = (0, import_react.useState)([]);
	const [landlordName, setLandlordName] = (0, import_react.useState)("");
	const [landlordPhone, setLandlordPhone] = (0, import_react.useState)("");
	const [notes, setNotes] = (0, import_react.useState)("");
	const [errors, setErrors] = (0, import_react.useState)({});
	const wasOpen = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		if (open && !wasOpen.current) {
			setName(room?.name ?? "");
			setDistrict(room?.district ?? "");
			setAddress(room?.address ?? "");
			setPrice(room ? trieuInput(room.price) : "");
			setType(room?.type ?? "tro");
			setArea(room?.areaM2 ? String(room.areaM2) : "");
			setAmenities(room?.amenities ?? []);
			setLandlordName(room?.landlordName ?? "");
			setLandlordPhone(room?.landlordPhone ?? "");
			setNotes(room?.notes ?? "");
			setErrors({});
		}
		wasOpen.current = open;
	}, [open, room]);
	function submit() {
		const next = {};
		if (!name.trim()) next.name = "Nhập tên gọi của phòng.";
		if (!district.trim()) next.district = "Nhập quận hoặc khu vực.";
		const money = readTrieu(price, true);
		if (!money.ok) next.price = money.error;
		const size = readArea(area);
		if (!size.ok) next.area = size.error;
		setErrors(next);
		if (Object.keys(next).length || !money.ok || !size.ok) return;
		const input = {
			name: name.trim(),
			district: district.trim(),
			address: address.trim(),
			price: money.value,
			type,
			areaM2: size.value,
			amenities,
			landlordName: landlordName.trim(),
			landlordPhone: landlordPhone.trim(),
			notes: notes.trim()
		};
		if (room) {
			updateRoom(room.id, input);
			onSaved?.(room.id);
		} else onSaved?.(addRoom(input));
		onOpenChange(false);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
		open,
		onOpenChange,
		title: room ? "Sửa phòng" : "Thêm phòng",
		description: "Giá tính bằng triệu đồng mỗi tháng.",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "grid gap-4",
			onSubmit: (event) => {
				event.preventDefault();
				submit();
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Tên gọi",
					error: errors.name,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: fieldClass,
						value: name,
						onChange: (event) => setName(event.target.value),
						placeholder: "Gác 20m² gần chợ Bà Chiểu"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4 sm:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Khu vực",
						error: errors.district,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: fieldClass,
							value: district,
							onChange: (event) => setDistrict(event.target.value),
							placeholder: "Bình Thạnh"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Loại phòng",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: fieldClass,
							value: type,
							onChange: (event) => setType(event.target.value),
							children: Object.entries(ROOM_TYPES).map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: id,
								children: label
							}, id))
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Địa chỉ",
					hint: "Không bắt buộc. Dùng khi dẫn khách.",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: fieldClass,
						value: address,
						onChange: (event) => setAddress(event.target.value),
						placeholder: "214/12 Xô Viết Nghệ Tĩnh"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4 sm:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Giá thuê (triệu/tháng)",
						error: errors.price,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: fieldClass,
							inputMode: "decimal",
							value: price,
							onChange: (event) => setPrice(event.target.value),
							placeholder: "3,2"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Diện tích (m²)",
						error: errors.area,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: fieldClass,
							inputMode: "decimal",
							value: area,
							onChange: (event) => setArea(event.target.value),
							placeholder: "20"
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
					className: "mb-1.5 text-sm font-medium",
					children: "Tiện ích"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-2",
					children: AMENITIES.map((item) => {
						const on = amenities.includes(item);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-pressed": on,
							onClick: () => setAmenities((current) => current.includes(item) ? current.filter((x) => x !== item) : [...current, item]),
							className: cn("min-h-11 rounded-full px-3 text-sm", on ? "bg-lacquer text-lacquer-ink" : "bg-paper text-ink shadow-card"),
							children: item
						}, item);
					})
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4 sm:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Chủ nhà",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: fieldClass,
							value: landlordName,
							onChange: (event) => setLandlordName(event.target.value),
							placeholder: "Chị Hạnh"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Số điện thoại",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: fieldClass,
							inputMode: "tel",
							value: landlordPhone,
							onChange: (event) => setLandlordPhone(event.target.value),
							placeholder: "0903 112 458"
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Ghi chú cho tin đăng",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						className: `${fieldClass} min-h-24 py-2`,
						value: notes,
						onChange: (event) => setNotes(event.target.value),
						placeholder: "Điện 4k, nước 100k, cọc 1 tháng…"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					className: "w-full",
					children: room ? "Lưu phòng" : "Thêm vào sổ"
				})
			]
		})
	});
}
function PageDialog({ open, onOpenChange, page }) {
	const addPage = useLedger((state) => state.addPage);
	const updatePage = useLedger((state) => state.updatePage);
	const [name, setName] = (0, import_react.useState)("");
	const [platform, setPlatform] = (0, import_react.useState)("facebook");
	const [url, setUrl] = (0, import_react.useState)("");
	const [note, setNote] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	const wasOpen = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		if (open && !wasOpen.current) {
			setName(page?.name ?? "");
			setPlatform(page?.platform ?? "facebook");
			setUrl(page?.url ?? "");
			setNote(page?.note ?? "");
			setError("");
		}
		wasOpen.current = open;
	}, [open, page]);
	function submit() {
		if (!name.trim()) {
			setError("Nhập tên trang hoặc nhóm.");
			return;
		}
		const input = {
			name: name.trim(),
			platform,
			url: url.trim(),
			note: note.trim()
		};
		if (page) updatePage(page.id, input);
		else addPage(input);
		onOpenChange(false);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
		open,
		onOpenChange,
		title: page ? "Sửa trang" : "Thêm trang",
		description: "Nhóm Facebook, Zalo, Chợ Tốt, TikTok hoặc chỗ bạn hay đăng.",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "grid gap-4",
			onSubmit: (event) => {
				event.preventDefault();
				submit();
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Tên trang",
					error,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: fieldClass,
						value: name,
						onChange: (event) => setName(event.target.value),
						placeholder: "Hội phòng trọ Bình Thạnh"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Nền tảng",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: fieldClass,
						value: platform,
						onChange: (event) => setPlatform(event.target.value),
						children: Object.entries(PLATFORMS).map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: id,
							children: label
						}, id))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Link trang",
					hint: "Không bắt buộc.",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: fieldClass,
						inputMode: "url",
						value: url,
						onChange: (event) => setUrl(event.target.value),
						placeholder: "https://"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Ghi chú",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						className: `${fieldClass} min-h-24 py-2`,
						value: note,
						onChange: (event) => setNote(event.target.value),
						placeholder: "Đăng buổi sáng, nhóm không cho giá ảo…"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					className: "w-full",
					children: page ? "Lưu trang" : "Thêm trang"
				})
			]
		})
	});
}
function ToggleList({ items, selected, onToggle }) {
	if (items.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted",
		children: "Chưa có mục nào."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "max-h-52 space-y-2 overflow-y-auto",
		children: items.map((item) => {
			const on = selected.includes(item.id);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				"aria-pressed": on,
				onClick: () => onToggle(item.id),
				className: cn("flex min-h-11 w-full items-center justify-between gap-3 rounded-xl px-3 text-left", on ? "bg-lacquer-soft" : "bg-paper"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block truncate text-sm font-medium",
						children: item.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block truncate text-sm text-muted",
						children: item.meta
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: cn("grid size-5 shrink-0 place-items-center rounded-full border", on ? "border-lacquer bg-lacquer text-lacquer-ink" : "border-line"),
					"aria-hidden": true,
					children: on ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3" }) : null
				})]
			}) }, item.id);
		})
	});
}
function PostDialog({ open, onOpenChange, roomId, pageId }) {
	const rooms = useLedger((state) => state.rooms);
	const pages = useLedger((state) => state.pages);
	const logPosts = useLedger((state) => state.logPosts);
	const [roomIds, setRoomIds] = (0, import_react.useState)([]);
	const [pageIds, setPageIds] = (0, import_react.useState)([]);
	const [date, setDate] = (0, import_react.useState)(todayISO());
	const [note, setNote] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	const wasOpen = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		if (open && !wasOpen.current) {
			setRoomIds(roomId ? [roomId] : []);
			setPageIds(pageId ? [pageId] : []);
			setDate(todayISO());
			setNote("");
			setError("");
		}
		wasOpen.current = open;
	}, [
		open,
		roomId,
		pageId
	]);
	const lockedRoom = roomId ? rooms.find((room) => room.id === roomId) : void 0;
	const lockedPage = pageId ? pages.find((page) => page.id === pageId) : void 0;
	function toggle(list, id, setList) {
		setList(list.includes(id) ? list.filter((item) => item !== id) : [...list, id]);
	}
	function submit() {
		const chosenRooms = roomId ? [roomId] : roomIds;
		const chosenPages = pageId ? [pageId] : pageIds;
		if (!date) {
			setError("Chọn ngày đăng.");
			return;
		}
		if (chosenRooms.length === 0 || chosenPages.length === 0) {
			setError("Chọn ít nhất một phòng và một trang.");
			return;
		}
		logPosts({
			roomIds: chosenRooms,
			pageIds: chosenPages,
			postedAt: date,
			note: note.trim()
		});
		onOpenChange(false);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
		open,
		onOpenChange,
		title: "Ghi đã đăng",
		description: "Đánh dấu phòng đã lên những trang nào, để khỏi đăng trùng.",
		children: rooms.length === 0 || pages.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: rooms.length === 0 ? "Chưa có phòng trong sổ." : "Chưa có trang nào. Thêm nhóm Facebook, Zalo hoặc Chợ Tốt trước."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: rooms.length === 0 ? "/rooms" : "/pages",
				className: "inline-flex min-h-11 items-center justify-center rounded-full bg-lacquer px-4 text-sm font-medium text-lacquer-ink",
				onClick: () => onOpenChange(false),
				children: rooms.length === 0 ? "Tới phòng" : "Tới trang"
			})]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "grid gap-4",
			onSubmit: (event) => {
				event.preventDefault();
				submit();
			},
			children: [
				lockedRoom ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm",
					children: ["Phòng: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: lockedRoom.name
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Phòng",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleList, {
						items: rooms.map((room) => ({
							id: room.id,
							title: room.name,
							meta: room.district
						})),
						selected: roomIds,
						onToggle: (id) => toggle(roomIds, id, setRoomIds)
					})
				}),
				lockedPage ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm",
					children: ["Trang: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: lockedPage.name
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Trang đã đăng",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleList, {
						items: pages.map((page) => ({
							id: page.id,
							title: page.name,
							meta: PLATFORMS[page.platform]
						})),
						selected: pageIds,
						onToggle: (id) => toggle(pageIds, id, setPageIds)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Ngày đăng",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "date",
						className: fieldClass,
						value: date,
						onChange: (event) => setDate(event.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Link bài hoặc ghi chú",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: fieldClass,
						value: note,
						onChange: (event) => setNote(event.target.value),
						placeholder: "Dán link bài nếu có"
					})
				}),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-lacquer",
					children: error
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					className: "w-full",
					children: "Lưu bài đăng"
				})
			]
		})
	});
}
function CloseDialog({ open, onOpenChange, room }) {
	const closeRoom = useLedger((state) => state.closeRoom);
	const [commission, setCommission] = (0, import_react.useState)("");
	const [date, setDate] = (0, import_react.useState)(todayISO());
	const [note, setNote] = (0, import_react.useState)("");
	const [removePosts, setRemovePosts] = (0, import_react.useState)(true);
	const [error, setError] = (0, import_react.useState)("");
	const wasOpen = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		if (open && !wasOpen.current) {
			const editing = room.status === "closed";
			setCommission(trieuInput(room.commission));
			setDate(editing && room.closedAt ? room.closedAt : todayISO());
			setNote(editing ? room.closeNote : "");
			setRemovePosts(!editing);
			setError("");
		}
		wasOpen.current = open;
	}, [open, room]);
	function submit() {
		const money = readTrieu(commission, false);
		if (!money.ok) {
			setError(money.error);
			return;
		}
		if (!date) {
			setError("Chọn ngày chốt.");
			return;
		}
		closeRoom(room.id, {
			commission: money.value,
			closedAt: date,
			closeNote: note.trim(),
			removePosts
		});
		onOpenChange(false);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
		open,
		onOpenChange,
		title: "Chốt sale",
		description: "Ghi hoa hồng và ngày khách lấy phòng.",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "grid gap-4",
			onSubmit: (event) => {
				event.preventDefault();
				submit();
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium",
					children: room.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Hoa hồng (triệu)",
					error,
					hint: "Để trống nếu chưa nhận.",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: fieldClass,
						inputMode: "decimal",
						value: commission,
						onChange: (event) => setCommission(event.target.value),
						placeholder: "1,5"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Ngày chốt",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "date",
						className: fieldClass,
						value: date,
						onChange: (event) => setDate(event.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Ghi chú khách",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: fieldClass,
						value: note,
						onChange: (event) => setNote(event.target.value),
						placeholder: "Khách couple, vào cuối tháng"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					"aria-pressed": removePosts,
					onClick: () => setRemovePosts((value) => !value),
					className: "flex min-h-11 items-center justify-between gap-3 rounded-xl bg-paper px-3 text-left text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Đánh dấu đã gỡ bài trên các trang" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: cn("grid size-5 place-items-center rounded-full border", removePosts ? "border-lacquer bg-lacquer text-lacquer-ink" : "border-line"),
						"aria-hidden": true,
						children: removePosts ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3" }) : null
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					className: "w-full",
					children: "Lưu phòng đã chốt"
				})
			]
		})
	});
}
var NAV = [
	{
		to: "/",
		label: "Hôm nay",
		icon: CalendarDays,
		exact: true
	},
	{
		to: "/rooms",
		label: "Phòng",
		icon: KeyRound,
		exact: false
	},
	{
		to: "/pages",
		label: "Trang",
		icon: Megaphone,
		exact: false
	}
];
function useReady() {
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		let alive = true;
		Promise.resolve(useLedger.persist.rehydrate()).finally(() => {
			if (alive) setReady(true);
		});
		return () => {
			alive = false;
		};
	}, []);
	return ready;
}
function isActive(pathname, to, exact) {
	if (exact) return pathname === to;
	return pathname === to || pathname.startsWith(`${to}/`);
}
function Shell({ children }) {
	const ready = useReady();
	const pathname = useRouterState({ select: (state) => state.location.pathname });
	const demo = useLedger((state) => state.demo);
	const clearAll = useLedger((state) => state.clearAll);
	const [confirm, setConfirm] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "fixed inset-y-0 left-0 z-30 hidden w-60 flex-col border-r border-line bg-surface px-4 py-6 md:flex",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3 px-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "grid size-11 place-items-center rounded-2xl bg-lacquer text-lacquer-ink",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, {
								className: "size-5",
								"aria-hidden": true
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block font-display text-2xl leading-none",
							children: "Sổ Sale"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-1 block text-xs text-muted",
							children: "Phòng đã chốt & trang đã đăng"
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "mt-8 flex flex-col gap-1",
						children: NAV.map((item) => {
							const on = isActive(pathname, item.to, item.exact);
							const Icon = item.icon;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: item.to,
								"aria-current": on ? "page" : void 0,
								className: cn("flex min-h-11 items-center gap-3 rounded-2xl px-3 text-sm font-medium", on ? "bg-lacquer text-lacquer-ink" : "text-muted"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
									className: "size-5",
									"aria-hidden": true
								}), item.label]
							}, item.to);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-auto px-2 text-xs text-muted",
						children: "Dữ liệu nằm trên máy này."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "md:pl-60",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto w-full max-w-5xl px-4 pt-5 pb-28 md:px-8 md:pt-8 md:pb-12",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
							className: "mb-5 flex items-center gap-2 md:hidden",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "grid size-9 place-items-center rounded-xl bg-lacquer text-lacquer-ink",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, {
									className: "size-4",
									"aria-hidden": true
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-display text-xl",
								children: "Sổ Sale"
							})]
						}),
						ready && demo ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-4 flex flex-col gap-3 rounded-2xl bg-lacquer-soft px-4 py-3 sm:flex-row sm:items-center sm:justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm",
								children: "Đang xem sổ mẫu ở Sài Gòn. Xóa hết khi bạn bắt đầu sổ thật."
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "quiet",
								onClick: () => setConfirm(true),
								className: "shrink-0",
								children: "Xóa dữ liệu mẫu"
							})]
						}) : null,
						ready ? children : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Boot, {})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "dock fixed inset-x-0 bottom-0 z-30 border-t border-line bg-surface md:hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-3",
					children: NAV.map((item) => {
						const on = isActive(pathname, item.to, item.exact);
						const Icon = item.icon;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: item.to,
							"aria-current": on ? "page" : void 0,
							className: cn("flex min-h-16 flex-col items-center justify-center gap-1 text-xs font-medium", on ? "text-lacquer" : "text-muted"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
								className: "size-5",
								"aria-hidden": true
							}), item.label]
						}, item.to);
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: confirm,
				onOpenChange: setConfirm,
				title: "Xóa toàn bộ sổ?",
				body: "Phòng, trang và bài đăng đang có trên máy này sẽ mất. Không hoàn tác được.",
				confirmLabel: "Xóa hết",
				onConfirm: clearAll
			})
		]
	});
}
function Boot() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "font-display text-4xl",
		children: "Sổ Sale"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mt-2 text-muted",
		children: "Đang mở sổ phòng trọ…"
	})] });
}
var styles_default = "/assets/styles-B_eQLcpq.css";
var APP_NAME = "Sổ Sale";
var Route$5 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: APP_NAME },
			{
				name: "description",
				content: "Sổ tay phòng trọ đã chốt, hoa hồng và các trang đã đăng bài."
			},
			{
				name: "theme-color",
				content: "#9f2d0f"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			}
		]
	}),
	component: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "vi",
		className: "antialiased",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", {
			className: "bg-paper font-sans text-ink",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
			]
		})]
	})
});
var $$splitComponentImporter$4 = () => import("./routes-DHcjDEXz.mjs");
var Route$4 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./pages-glj_3kEv.mjs");
var Route$3 = createFileRoute("/pages/")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("../_pageId-C3f8kqyP.mjs");
var Route$2 = createFileRoute("/pages/$pageId")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./rooms-CjRr-2Pm.mjs");
var Route$1 = createFileRoute("/rooms/")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("../_roomId-Cg37DcfQ.mjs");
var Route = createFileRoute("/rooms/$roomId")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var IndexRoute = Route$4.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$5
});
var PagesIndexRoute = Route$3.update({
	id: "/pages/",
	path: "/pages/",
	getParentRoute: () => Route$5
});
var PagesPageIdRoute = Route$2.update({
	id: "/pages/$pageId",
	path: "/pages/$pageId",
	getParentRoute: () => Route$5
});
var RoomsIndexRoute = Route$1.update({
	id: "/rooms/",
	path: "/rooms/",
	getParentRoute: () => Route$5
});
var rootRouteChildren = {
	IndexRoute,
	PagesPageIdRoute,
	RoomsRoomIdRoute: Route.update({
		id: "/rooms/$roomId",
		path: "/rooms/$roomId",
		getParentRoute: () => Route$5
	}),
	PagesIndexRoute,
	RoomsIndexRoute
};
var routeTree = Route$5._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		rewrite: previewPathRewrite(),
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { cn as A, relativeDay as C, EmptyState as D, Button as E, Modal as O, monthKey as S, Badge as T, formatDay as _, ConfirmDialog as a, formatVnd as b, RoomDialog as c, ROOM_STATUS as d, ROOM_TYPES as f, fold as g, useLedger as h, CloseDialog as i, fieldClass as k, PLATFORMS as l, needsRepost as m, Route as n, PageDialog as o, listingText as p, Route$2 as r, PostDialog as s, router_exports as t, PLATFORM_MARK as u, formatMonth as v, todayISO as w, isUrl as x, formatShort as y };
