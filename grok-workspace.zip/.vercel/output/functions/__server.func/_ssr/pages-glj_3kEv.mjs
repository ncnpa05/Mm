import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { A as cn, D as EmptyState, E as Button, g as fold, h as useLedger, l as PLATFORMS, o as PageDialog } from "./router-UWfdBrAR.mjs";
import { t as PageCard } from "./cards-C-aaxjvl.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/pages-glj_3kEv.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var CHIPS = [
	{
		id: "all",
		label: "Tất cả"
	},
	{
		id: "facebook",
		label: PLATFORMS.facebook
	},
	{
		id: "zalo",
		label: PLATFORMS.zalo
	},
	{
		id: "chotot",
		label: PLATFORMS.chotot
	},
	{
		id: "tiktok",
		label: PLATFORMS.tiktok
	},
	{
		id: "other",
		label: PLATFORMS.other
	}
];
function PagesPage() {
	const pages = useLedger((state) => state.pages);
	const posts = useLedger((state) => state.posts);
	const [platform, setPlatform] = (0, import_react.useState)("all");
	const [query, setQuery] = (0, import_react.useState)("");
	const [open, setOpen] = (0, import_react.useState)(false);
	const filtered = (0, import_react.useMemo)(() => {
		const needle = fold(query.trim());
		return pages.filter((page) => platform === "all" ? true : page.platform === platform).filter((page) => needle ? fold(`${page.name} ${page.note}`).includes(needle) : true).sort((a, b) => a.name.localeCompare(b.name, "vi"));
	}, [
		pages,
		platform,
		query
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-end justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl md:text-4xl",
				children: "Trang"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: "Nhóm và nền tảng bạn đã đăng bài."
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: () => setOpen(true),
				children: "Thêm trang"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			className: "mt-4 min-h-11 w-full rounded-xl bg-surface px-3 text-base shadow-card outline-none placeholder:text-muted",
			value: query,
			onChange: (event) => setQuery(event.target.value),
			placeholder: "Tìm tên nhóm…",
			"aria-label": "Tìm trang"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-3 flex flex-wrap gap-2",
			children: CHIPS.map((chip) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				"aria-pressed": platform === chip.id,
				onClick: () => setPlatform(chip.id),
				className: cn("min-h-11 rounded-full px-4 text-sm font-medium", platform === chip.id ? "bg-lacquer text-lacquer-ink" : "bg-surface text-ink shadow-card"),
				children: chip.label
			}, chip.id))
		}),
		pages.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				title: "Chưa có trang nào",
				body: "Thêm nhóm Facebook, Zalo, Chợ Tốt hoặc TikTok để biết căn nào đã đăng ở đâu.",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => setOpen(true),
					children: "Thêm trang đầu tiên"
				})
			})
		}) : filtered.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-6 rounded-2xl bg-surface px-4 py-4 text-sm text-muted shadow-card",
			children: "Không có trang khớp."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-4 grid gap-3 md:grid-cols-2",
			children: filtered.map((page) => {
				const related = posts.filter((post) => post.pageId === page.id);
				const last = related.reduce((max, post) => post.postedAt > max ? post.postedAt : max, "");
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageCard, {
					page,
					postCount: related.length,
					lastPosted: last || null
				}, page.id);
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageDialog, {
			open,
			onOpenChange: setOpen
		})
	] });
}
//#endregion
export { PagesPage as component };
