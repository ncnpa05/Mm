import { i as __toESM } from "./_runtime.mjs";
import { n as require_react } from "./_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as Link, x as useNavigate } from "./_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "./_libs/radix-ui__react-context+react.mjs";
import { a as MapPin, c as ChevronLeft, r as Phone } from "./_libs/lucide-react.mjs";
import { C as relativeDay, D as EmptyState, E as Button, O as Modal, T as Badge, a as ConfirmDialog, b as formatVnd, c as RoomDialog, d as ROOM_STATUS, f as ROOM_TYPES, h as useLedger, i as CloseDialog, k as fieldClass, n as Route, p as listingText, s as PostDialog, w as todayISO, x as isUrl, y as formatShort } from "./_ssr/router-UWfdBrAR.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_roomId-Cg37DcfQ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function tone(status) {
	if (status === "closed") return "moss";
	if (status === "viewing") return "ink";
	if (status === "posted") return "muted";
	return "lacquer";
}
function RoomPage() {
	const { roomId } = Route.useParams();
	const navigate = useNavigate();
	const room = useLedger((state) => state.rooms.find((item) => item.id === roomId));
	const pages = useLedger((state) => state.pages);
	const posts = useLedger((state) => state.posts.filter((post) => post.roomId === roomId).sort((a, b) => b.postedAt.localeCompare(a.postedAt)));
	const setStatus = useLedger((state) => state.setStatus);
	const setPostStatus = useLedger((state) => state.setPostStatus);
	const deleteRoom = useLedger((state) => state.deleteRoom);
	const reopenRoom = useLedger((state) => state.reopenRoom);
	const [edit, setEdit] = (0, import_react.useState)(false);
	const [log, setLog] = (0, import_react.useState)(false);
	const [close, setClose] = (0, import_react.useState)(false);
	const [remove, setRemove] = (0, import_react.useState)(false);
	const [reopen, setReopen] = (0, import_react.useState)(false);
	const [copied, setCopied] = (0, import_react.useState)(false);
	const [manual, setManual] = (0, import_react.useState)(null);
	const today = todayISO();
	if (!room) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
		title: "Không thấy phòng này",
		body: "Có thể phòng đã bị xóa khỏi sổ.",
		action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/rooms",
			className: "inline-flex min-h-11 items-center rounded-full bg-lacquer px-4 text-sm font-medium text-lacquer-ink",
			children: "Về danh sách"
		})
	});
	const mapQuery = encodeURIComponent([room.address, room.district].filter(Boolean).join(", "));
	const phone = room.landlordPhone.replace(/[^\d+]/g, "");
	async function copyListing() {
		const text = listingText(room);
		try {
			await navigator.clipboard.writeText(text);
			setCopied(true);
			window.setTimeout(() => setCopied(false), 2e3);
		} catch {
			setManual(text);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-3xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/rooms",
				className: "inline-flex min-h-11 items-center gap-1 text-sm font-medium text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, {
					className: "size-4",
					"aria-hidden": true
				}), "Phòng"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-2 flex flex-wrap items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							tone: tone(room.status),
							children: ROOM_STATUS[room.status]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-2 font-display text-3xl break-words md:text-4xl",
							children: room.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-muted",
							children: [
								room.district,
								" · ",
								ROOM_TYPES[room.type],
								room.areaM2 ? ` · ${room.areaM2}m²` : ""
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-3xl tabular-nums",
					children: formatVnd(room.price)
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 grid gap-2",
				children: [room.landlordPhone ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					href: `tel:${phone}`,
					className: "flex min-h-14 items-center justify-between gap-3 rounded-2xl bg-surface px-4 shadow-card",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-sm text-muted",
						children: "Chủ nhà"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-medium",
						children: [room.landlordName ? `${room.landlordName} · ` : "", room.landlordPhone]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, {
						className: "size-5 text-lacquer",
						"aria-hidden": true
					})]
				}) : null, room.address || room.district ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					href: `https://www.google.com/maps/search/?api=1&query=${mapQuery}`,
					target: "_blank",
					rel: "noreferrer",
					className: "flex min-h-14 items-center justify-between gap-3 rounded-2xl bg-surface px-4 shadow-card",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-sm text-muted",
							children: "Địa chỉ"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block truncate font-medium",
							children: room.address || room.district
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, {
						className: "size-5 shrink-0 text-lacquer",
						"aria-hidden": true
					})]
				}) : null]
			}),
			room.amenities.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 flex flex-wrap gap-2",
				children: room.amenities.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "rounded-full bg-surface px-3 py-2 text-sm shadow-card",
					children: item
				}, item))
			}) : null,
			room.notes ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-sm text-muted",
				children: room.notes
			}) : null,
			room.status === "closed" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-5 rounded-2xl bg-moss-soft px-4 py-4 text-moss",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm font-medium",
						children: ["Đã chốt ", room.closedAt ? formatShort(room.closedAt) : ""]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 font-display text-3xl tabular-nums",
						children: formatVnd(room.commission ?? 0)
					}),
					room.closeNote ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm",
						children: room.closeNote
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex flex-wrap gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "quiet",
							onClick: () => setClose(true),
							children: "Sửa lần chốt"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "quiet",
							onClick: () => setReopen(true),
							children: "Mở lại phòng"
						})]
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 grid gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-3 gap-2",
						children: [
							["open", "Còn sale"],
							["posted", "Đã đăng"],
							["viewing", "Đang xem"]
						].map(([status, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-pressed": room.status === status,
							onClick: () => setStatus(room.id, status),
							className: `min-h-11 rounded-full px-2 text-sm font-medium ${room.status === status ? "bg-ink text-surface" : "bg-surface text-ink shadow-card"}`,
							children: label
						}, status))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "quiet",
							onClick: () => void copyListing(),
							children: copied ? "Đã chép" : "Chép tin"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "quiet",
							onClick: () => setLog(true),
							children: "Ghi đã đăng"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => setClose(true),
						children: "Chốt sale"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3 flex items-end justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl",
						children: "Đã đăng ở đâu"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "quiet",
						size: "sm",
						onClick: () => setLog(true),
						children: "Thêm"
					})]
				}), posts.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "rounded-2xl bg-surface px-4 py-4 text-sm text-muted shadow-card",
					children: "Chưa ghi trang nào cho phòng này."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "rounded-2xl bg-surface px-4 shadow-card",
					children: posts.map((post) => {
						const page = pages.find((item) => item.id === post.pageId);
						if (!page) return null;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "border-b border-line py-3 last:border-0",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
											to: "/pages/$pageId",
											params: { pageId: page.id },
											className: "font-medium",
											children: page.name
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm text-muted",
											children: relativeDay(post.postedAt, today)
										}),
										isUrl(post.note) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
											href: post.note.trim(),
											target: "_blank",
											rel: "noreferrer",
											className: "text-sm font-medium text-lacquer",
											children: "Mở bài đăng"
										}) : post.note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm text-muted",
											children: post.note
										}) : null
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									size: "sm",
									onClick: () => setPostStatus(post.id, post.status === "live" ? "removed" : "live"),
									children: post.status === "live" ? "Gỡ bài" : "Đang hiện"
								})]
							})
						}, post.id);
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "quiet",
					onClick: () => setEdit(true),
					children: "Sửa phòng"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					onClick: () => setRemove(true),
					children: "Xóa"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoomDialog, {
				open: edit,
				onOpenChange: setEdit,
				room
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PostDialog, {
				open: log,
				onOpenChange: setLog,
				roomId: room.id
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CloseDialog, {
				open: close,
				onOpenChange: setClose,
				room
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: remove,
				onOpenChange: setRemove,
				title: "Xóa phòng này?",
				body: "Các lần đăng của phòng cũng bị xóa khỏi sổ.",
				confirmLabel: "Xóa phòng",
				onConfirm: () => {
					deleteRoom(room.id);
					navigate({ to: "/rooms" });
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: reopen,
				onOpenChange: setReopen,
				title: "Mở lại phòng?",
				body: "Hoa hồng và ngày chốt sẽ được xóa. Bài đã gỡ không tự đăng lại.",
				confirmLabel: "Mở lại",
				onConfirm: () => reopenRoom(room.id)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
				open: manual !== null,
				onOpenChange: (open) => {
					if (!open) setManual(null);
				},
				title: "Chép tin",
				description: "Chọn toàn bộ đoạn dưới rồi sao chép.",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					readOnly: true,
					className: `${fieldClass} min-h-48 py-2`,
					value: manual ?? ""
				})
			})
		]
	});
}
//#endregion
export { RoomPage as component };
