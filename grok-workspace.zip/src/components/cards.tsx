import { Link } from "@tanstack/react-router";
import { Badge, Button } from "@/components/ui";
import { formatShort, formatVnd } from "@/lib/format";
import {
  PLATFORM_MARK,
  PLATFORMS,
  ROOM_STATUS,
  ROOM_TYPES,
  type Page,
  type Room,
  type RoomStatus,
} from "@/lib/ledger";

function statusTone(status: RoomStatus): "lacquer" | "moss" | "ink" | "muted" {
  if (status === "closed") return "moss";
  if (status === "viewing") return "ink";
  if (status === "posted") return "muted";
  return "lacquer";
}

export function RoomCard({
  room,
  liveCount,
  onLog,
}: {
  room: Room;
  liveCount: number;
  onLog?: () => void;
}) {
  return (
    <article className="flex flex-col rounded-2xl bg-surface p-4 shadow-card transition-shadow duration-200 hover:shadow-card-hover">
      <div className="flex items-start justify-between gap-3">
        <Badge tone={statusTone(room.status)}>{ROOM_STATUS[room.status]}</Badge>
        <p className="shrink-0 font-display text-xl tabular-nums">{formatVnd(room.price)}</p>
      </div>
      <Link
        to="/rooms/$roomId"
        params={{ roomId: room.id }}
        className="mt-3 block min-w-0 flex-1"
      >
        <h3 className="text-lg font-semibold break-words">{room.name}</h3>
        <p className="mt-1 text-sm text-muted">
          {room.district} · {ROOM_TYPES[room.type]}
          {room.areaM2 ? ` · ${room.areaM2}m²` : ""}
        </p>
      </Link>
      <div className="mt-4 flex items-center justify-between gap-3">
        <p className="min-w-0 text-sm text-muted">
          {room.status === "closed"
            ? `Chốt ${room.closedAt ? formatShort(room.closedAt) : ""} · ${formatVnd(room.commission ?? 0)}`
            : liveCount
              ? `${liveCount} trang đang hiện`
              : "Chưa đăng trang nào"}
        </p>
        {room.status !== "closed" && onLog ? (
          <Button variant="quiet" size="sm" onClick={onLog} className="shrink-0">
            Ghi đã đăng
          </Button>
        ) : null}
      </div>
    </article>
  );
}

export function PageCard({
  page,
  postCount,
  lastPosted,
}: {
  page: Page;
  postCount: number;
  lastPosted: string | null;
}) {
  return (
    <Link
      to="/pages/$pageId"
      params={{ pageId: page.id }}
      className="block rounded-2xl bg-surface p-4 shadow-card transition-shadow duration-200 hover:shadow-card-hover"
    >
      <div className="flex items-center gap-3">
        <span className="grid size-11 shrink-0 place-items-center rounded-2xl bg-paper text-sm font-semibold">
          {PLATFORM_MARK[page.platform]}
        </span>
        <span className="min-w-0">
          <span className="block truncate font-semibold">{page.name}</span>
          <span className="block text-sm text-muted">
            {PLATFORMS[page.platform]} · {postCount} bài
            {lastPosted ? ` · ${formatShort(lastPosted)}` : ""}
          </span>
        </span>
      </div>
    </Link>
  );
}
