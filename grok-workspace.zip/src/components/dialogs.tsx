import { useEffect, useRef, useState } from "react";
import { Link } from "@tanstack/react-router";
import { Check } from "lucide-react";
import { Button, Field, Modal, fieldClass } from "@/components/ui";
import { todayISO, trieuInput } from "@/lib/format";
import {
  AMENITIES,
  PLATFORMS,
  ROOM_TYPES,
  useLedger,
  type PageInput,
  type Platform,
  type Room,
  type RoomInput,
  type RoomType,
} from "@/lib/ledger";
import { cn } from "@/lib/utils";

function readTrieu(raw: string, required: boolean): { ok: true; value: number } | { ok: false; error: string } {
  if (!raw.trim()) {
    return required
      ? { ok: false, error: "Nhập số tiền, đơn vị triệu. Ví dụ 3,2." }
      : { ok: true, value: 0 };
  }
  const value = Number(raw.trim().replace(/\s/g, "").replace(",", "."));
  if (!Number.isFinite(value) || value < 0 || (required && value === 0)) {
    return { ok: false, error: "Số tiền chưa đúng." };
  }
  if (value > 500) {
    return { ok: false, error: "Nhập theo triệu. Ví dụ 3,2 chứ không phải 3200000." };
  }
  return { ok: true, value: Math.round(value * 1_000_000) };
}

function readArea(raw: string): { ok: true; value: number | null } | { ok: false; error: string } {
  if (!raw.trim()) return { ok: true, value: null };
  const value = Number(raw.trim().replace(",", "."));
  if (!Number.isFinite(value) || value <= 0 || value > 1000) {
    return { ok: false, error: "Diện tích chưa đúng." };
  }
  return { ok: true, value: Math.round(value) };
}

export function ConfirmDialog({
  open,
  onOpenChange,
  title,
  body,
  confirmLabel,
  onConfirm,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: string;
  body: string;
  confirmLabel: string;
  onConfirm: () => void;
}) {
  return (
    <Modal open={open} onOpenChange={onOpenChange} title={title} description={body}>
      <div className="grid grid-cols-2 gap-2">
        <Button variant="quiet" onClick={() => onOpenChange(false)}>
          Hủy
        </Button>
        <Button
          onClick={() => {
            onConfirm();
            onOpenChange(false);
          }}
        >
          {confirmLabel}
        </Button>
      </div>
    </Modal>
  );
}

export function RoomDialog({
  open,
  onOpenChange,
  room,
  onSaved,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  room?: Room;
  onSaved?: (id: string) => void;
}) {
  const addRoom = useLedger((state) => state.addRoom);
  const updateRoom = useLedger((state) => state.updateRoom);
  const [name, setName] = useState("");
  const [district, setDistrict] = useState("");
  const [address, setAddress] = useState("");
  const [price, setPrice] = useState("");
  const [type, setType] = useState<RoomType>("tro");
  const [area, setArea] = useState("");
  const [amenities, setAmenities] = useState<string[]>([]);
  const [landlordName, setLandlordName] = useState("");
  const [landlordPhone, setLandlordPhone] = useState("");
  const [notes, setNotes] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const wasOpen = useRef(false);

  useEffect(() => {
    if (open && !wasOpen.current) {
      setName(room?.name ?? "");
      setDistrict(room?.district ?? "");
      setAddress(room?.address ?? "");
      setPrice(room ? trieuInput(room.price) : "");
      setType(room?.type ?? "tro");
      setArea(room?.areaM2 ? String(room.areaM2) : "");
      setAmenities(room?.amenities ?? []);
      setLandlordName(room?.landlordName ?? "");
      setLandlordPhone(room?.landlordPhone ?? "");
      setNotes(room?.notes ?? "");
      setErrors({});
    }
    wasOpen.current = open;
  }, [open, room]);

  function submit() {
    const next: Record<string, string> = {};
    if (!name.trim()) next.name = "Nhập tên gọi của phòng.";
    if (!district.trim()) next.district = "Nhập quận hoặc khu vực.";
    const money = readTrieu(price, true);
    if (!money.ok) next.price = money.error;
    const size = readArea(area);
    if (!size.ok) next.area = size.error;
    setErrors(next);
    if (Object.keys(next).length || !money.ok || !size.ok) return;
    const input: RoomInput = {
      name: name.trim(),
      district: district.trim(),
      address: address.trim(),
      price: money.value,
      type,
      areaM2: size.value,
      amenities,
      landlordName: landlordName.trim(),
      landlordPhone: landlordPhone.trim(),
      notes: notes.trim(),
    };
    if (room) {
      updateRoom(room.id, input);
      onSaved?.(room.id);
    } else {
      onSaved?.(addRoom(input));
    }
    onOpenChange(false);
  }

  return (
    <Modal
      open={open}
      onOpenChange={onOpenChange}
      title={room ? "Sửa phòng" : "Thêm phòng"}
      description="Giá tính bằng triệu đồng mỗi tháng."
    >
      <form
        className="grid gap-4"
        onSubmit={(event) => {
          event.preventDefault();
          submit();
        }}
      >
        <Field label="Tên gọi" error={errors.name}>
          <input
            className={fieldClass}
            value={name}
            onChange={(event) => setName(event.target.value)}
            placeholder="Gác 20m² gần chợ Bà Chiểu"
          />
        </Field>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Khu vực" error={errors.district}>
            <input
              className={fieldClass}
              value={district}
              onChange={(event) => setDistrict(event.target.value)}
              placeholder="Bình Thạnh"
            />
          </Field>
          <Field label="Loại phòng">
            <select
              className={fieldClass}
              value={type}
              onChange={(event) => setType(event.target.value as RoomType)}
            >
              {Object.entries(ROOM_TYPES).map(([id, label]) => (
                <option key={id} value={id}>
                  {label}
                </option>
              ))}
            </select>
          </Field>
        </div>
        <Field label="Địa chỉ" hint="Không bắt buộc. Dùng khi dẫn khách.">
          <input
            className={fieldClass}
            value={address}
            onChange={(event) => setAddress(event.target.value)}
            placeholder="214/12 Xô Viết Nghệ Tĩnh"
          />
        </Field>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Giá thuê (triệu/tháng)" error={errors.price}>
            <input
              className={fieldClass}
              inputMode="decimal"
              value={price}
              onChange={(event) => setPrice(event.target.value)}
              placeholder="3,2"
            />
          </Field>
          <Field label="Diện tích (m²)" error={errors.area}>
            <input
              className={fieldClass}
              inputMode="decimal"
              value={area}
              onChange={(event) => setArea(event.target.value)}
              placeholder="20"
            />
          </Field>
        </div>
        <fieldset>
          <legend className="mb-1.5 text-sm font-medium">Tiện ích</legend>
          <div className="flex flex-wrap gap-2">
            {AMENITIES.map((item) => {
              const on = amenities.includes(item);
              return (
                <button
                  key={item}
                  type="button"
                  aria-pressed={on}
                  onClick={() =>
                    setAmenities((current) =>
                      current.includes(item) ? current.filter((x) => x !== item) : [...current, item],
                    )
                  }
                  className={cn(
                    "min-h-11 rounded-full px-3 text-sm",
                    on ? "bg-lacquer text-lacquer-ink" : "bg-paper text-ink shadow-card",
                  )}
                >
                  {item}
                </button>
              );
            })}
          </div>
        </fieldset>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Chủ nhà">
            <input
              className={fieldClass}
              value={landlordName}
              onChange={(event) => setLandlordName(event.target.value)}
              placeholder="Chị Hạnh"
            />
          </Field>
          <Field label="Số điện thoại">
            <input
              className={fieldClass}
              inputMode="tel"
              value={landlordPhone}
              onChange={(event) => setLandlordPhone(event.target.value)}
              placeholder="0903 112 458"
            />
          </Field>
        </div>
        <Field label="Ghi chú cho tin đăng">
          <textarea
            className={`${fieldClass} min-h-24 py-2`}
            value={notes}
            onChange={(event) => setNotes(event.target.value)}
            placeholder="Điện 4k, nước 100k, cọc 1 tháng…"
          />
        </Field>
        <Button type="submit" className="w-full">
          {room ? "Lưu phòng" : "Thêm vào sổ"}
        </Button>
      </form>
    </Modal>
  );
}

export function PageDialog({
  open,
  onOpenChange,
  page,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  page?: { id: string; name: string; platform: Platform; url: string; note: string };
}) {
  const addPage = useLedger((state) => state.addPage);
  const updatePage = useLedger((state) => state.updatePage);
  const [name, setName] = useState("");
  const [platform, setPlatform] = useState<Platform>("facebook");
  const [url, setUrl] = useState("");
  const [note, setNote] = useState("");
  const [error, setError] = useState("");
  const wasOpen = useRef(false);

  useEffect(() => {
    if (open && !wasOpen.current) {
      setName(page?.name ?? "");
      setPlatform(page?.platform ?? "facebook");
      setUrl(page?.url ?? "");
      setNote(page?.note ?? "");
      setError("");
    }
    wasOpen.current = open;
  }, [open, page]);

  function submit() {
    if (!name.trim()) {
      setError("Nhập tên trang hoặc nhóm.");
      return;
    }
    const input: PageInput = {
      name: name.trim(),
      platform,
      url: url.trim(),
      note: note.trim(),
    };
    if (page) updatePage(page.id, input);
    else addPage(input);
    onOpenChange(false);
  }

  return (
    <Modal
      open={open}
      onOpenChange={onOpenChange}
      title={page ? "Sửa trang" : "Thêm trang"}
      description="Nhóm Facebook, Zalo, Chợ Tốt, TikTok hoặc chỗ bạn hay đăng."
    >
      <form
        className="grid gap-4"
        onSubmit={(event) => {
          event.preventDefault();
          submit();
        }}
      >
        <Field label="Tên trang" error={error}>
          <input
            className={fieldClass}
            value={name}
            onChange={(event) => setName(event.target.value)}
            placeholder="Hội phòng trọ Bình Thạnh"
          />
        </Field>
        <Field label="Nền tảng">
          <select
            className={fieldClass}
            value={platform}
            onChange={(event) => setPlatform(event.target.value as Platform)}
          >
            {Object.entries(PLATFORMS).map(([id, label]) => (
              <option key={id} value={id}>
                {label}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Link trang" hint="Không bắt buộc.">
          <input
            className={fieldClass}
            inputMode="url"
            value={url}
            onChange={(event) => setUrl(event.target.value)}
            placeholder="https://"
          />
        </Field>
        <Field label="Ghi chú">
          <textarea
            className={`${fieldClass} min-h-24 py-2`}
            value={note}
            onChange={(event) => setNote(event.target.value)}
            placeholder="Đăng buổi sáng, nhóm không cho giá ảo…"
          />
        </Field>
        <Button type="submit" className="w-full">
          {page ? "Lưu trang" : "Thêm trang"}
        </Button>
      </form>
    </Modal>
  );
}

function ToggleList({
  items,
  selected,
  onToggle,
}: {
  items: { id: string; title: string; meta: string }[];
  selected: string[];
  onToggle: (id: string) => void;
}) {
  if (items.length === 0) return <p className="text-sm text-muted">Chưa có mục nào.</p>;
  return (
    <ul className="max-h-52 space-y-2 overflow-y-auto">
      {items.map((item) => {
        const on = selected.includes(item.id);
        return (
          <li key={item.id}>
            <button
              type="button"
              aria-pressed={on}
              onClick={() => onToggle(item.id)}
              className={cn(
                "flex min-h-11 w-full items-center justify-between gap-3 rounded-xl px-3 text-left",
                on ? "bg-lacquer-soft" : "bg-paper",
              )}
            >
              <span className="min-w-0">
                <span className="block truncate text-sm font-medium">{item.title}</span>
                <span className="block truncate text-sm text-muted">{item.meta}</span>
              </span>
              <span
                className={cn(
                  "grid size-5 shrink-0 place-items-center rounded-full border",
                  on ? "border-lacquer bg-lacquer text-lacquer-ink" : "border-line",
                )}
                aria-hidden
              >
                {on ? <Check className="size-3" /> : null}
              </span>
            </button>
          </li>
        );
      })}
    </ul>
  );
}

export function PostDialog({
  open,
  onOpenChange,
  roomId,
  pageId,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  roomId?: string;
  pageId?: string;
}) {
  const rooms = useLedger((state) => state.rooms);
  const pages = useLedger((state) => state.pages);
  const logPosts = useLedger((state) => state.logPosts);
  const [roomIds, setRoomIds] = useState<string[]>([]);
  const [pageIds, setPageIds] = useState<string[]>([]);
  const [date, setDate] = useState(todayISO());
  const [note, setNote] = useState("");
  const [error, setError] = useState("");
  const wasOpen = useRef(false);

  useEffect(() => {
    if (open && !wasOpen.current) {
      setRoomIds(roomId ? [roomId] : []);
      setPageIds(pageId ? [pageId] : []);
      setDate(todayISO());
      setNote("");
      setError("");
    }
    wasOpen.current = open;
  }, [open, roomId, pageId]);

  const lockedRoom = roomId ? rooms.find((room) => room.id === roomId) : undefined;
  const lockedPage = pageId ? pages.find((page) => page.id === pageId) : undefined;

  function toggle(list: string[], id: string, setList: (ids: string[]) => void) {
    setList(list.includes(id) ? list.filter((item) => item !== id) : [...list, id]);
  }

  function submit() {
    const chosenRooms = roomId ? [roomId] : roomIds;
    const chosenPages = pageId ? [pageId] : pageIds;
    if (!date) {
      setError("Chọn ngày đăng.");
      return;
    }
    if (chosenRooms.length === 0 || chosenPages.length === 0) {
      setError("Chọn ít nhất một phòng và một trang.");
      return;
    }
    logPosts({ roomIds: chosenRooms, pageIds: chosenPages, postedAt: date, note: note.trim() });
    onOpenChange(false);
  }

  return (
    <Modal
      open={open}
      onOpenChange={onOpenChange}
      title="Ghi đã đăng"
      description="Đánh dấu phòng đã lên những trang nào, để khỏi đăng trùng."
    >
      {rooms.length === 0 || pages.length === 0 ? (
        <div className="grid gap-3">
          <p className="text-sm text-muted">
            {rooms.length === 0
              ? "Chưa có phòng trong sổ."
              : "Chưa có trang nào. Thêm nhóm Facebook, Zalo hoặc Chợ Tốt trước."}
          </p>
          <Link
            to={rooms.length === 0 ? "/rooms" : "/pages"}
            className="inline-flex min-h-11 items-center justify-center rounded-full bg-lacquer px-4 text-sm font-medium text-lacquer-ink"
            onClick={() => onOpenChange(false)}
          >
            {rooms.length === 0 ? "Tới phòng" : "Tới trang"}
          </Link>
        </div>
      ) : (
        <form
          className="grid gap-4"
          onSubmit={(event) => {
            event.preventDefault();
            submit();
          }}
        >
          {lockedRoom ? (
            <p className="text-sm">
              Phòng: <span className="font-medium">{lockedRoom.name}</span>
            </p>
          ) : (
            <Field label="Phòng">
              <ToggleList
                items={rooms.map((room) => ({
                  id: room.id,
                  title: room.name,
                  meta: room.district,
                }))}
                selected={roomIds}
                onToggle={(id) => toggle(roomIds, id, setRoomIds)}
              />
            </Field>
          )}
          {lockedPage ? (
            <p className="text-sm">
              Trang: <span className="font-medium">{lockedPage.name}</span>
            </p>
          ) : (
            <Field label="Trang đã đăng">
              <ToggleList
                items={pages.map((page) => ({
                  id: page.id,
                  title: page.name,
                  meta: PLATFORMS[page.platform],
                }))}
                selected={pageIds}
                onToggle={(id) => toggle(pageIds, id, setPageIds)}
              />
            </Field>
          )}
          <Field label="Ngày đăng">
            <input
              type="date"
              className={fieldClass}
              value={date}
              onChange={(event) => setDate(event.target.value)}
            />
          </Field>
          <Field label="Link bài hoặc ghi chú">
            <input
              className={fieldClass}
              value={note}
              onChange={(event) => setNote(event.target.value)}
              placeholder="Dán link bài nếu có"
            />
          </Field>
          {error ? <p className="text-sm text-lacquer">{error}</p> : null}
          <Button type="submit" className="w-full">
            Lưu bài đăng
          </Button>
        </form>
      )}
    </Modal>
  );
}

export function CloseDialog({
  open,
  onOpenChange,
  room,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  room: Room;
}) {
  const closeRoom = useLedger((state) => state.closeRoom);
  const [commission, setCommission] = useState("");
  const [date, setDate] = useState(todayISO());
  const [note, setNote] = useState("");
  const [removePosts, setRemovePosts] = useState(true);
  const [error, setError] = useState("");
  const wasOpen = useRef(false);

  useEffect(() => {
    if (open && !wasOpen.current) {
      const editing = room.status === "closed";
      setCommission(trieuInput(room.commission));
      setDate(editing && room.closedAt ? room.closedAt : todayISO());
      setNote(editing ? room.closeNote : "");
      setRemovePosts(!editing);
      setError("");
    }
    wasOpen.current = open;
  }, [open, room]);

  function submit() {
    const money = readTrieu(commission, false);
    if (!money.ok) {
      setError(money.error);
      return;
    }
    if (!date) {
      setError("Chọn ngày chốt.");
      return;
    }
    closeRoom(room.id, {
      commission: money.value,
      closedAt: date,
      closeNote: note.trim(),
      removePosts,
    });
    onOpenChange(false);
  }

  return (
    <Modal
      open={open}
      onOpenChange={onOpenChange}
      title="Chốt sale"
      description="Ghi hoa hồng và ngày khách lấy phòng."
    >
      <form
        className="grid gap-4"
        onSubmit={(event) => {
          event.preventDefault();
          submit();
        }}
      >
        <p className="text-sm font-medium">{room.name}</p>
        <Field label="Hoa hồng (triệu)" error={error} hint="Để trống nếu chưa nhận.">
          <input
            className={fieldClass}
            inputMode="decimal"
            value={commission}
            onChange={(event) => setCommission(event.target.value)}
            placeholder="1,5"
          />
        </Field>
        <Field label="Ngày chốt">
          <input
            type="date"
            className={fieldClass}
            value={date}
            onChange={(event) => setDate(event.target.value)}
          />
        </Field>
        <Field label="Ghi chú khách">
          <input
            className={fieldClass}
            value={note}
            onChange={(event) => setNote(event.target.value)}
            placeholder="Khách couple, vào cuối tháng"
          />
        </Field>
        <button
          type="button"
          aria-pressed={removePosts}
          onClick={() => setRemovePosts((value) => !value)}
          className="flex min-h-11 items-center justify-between gap-3 rounded-xl bg-paper px-3 text-left text-sm"
        >
          <span>Đánh dấu đã gỡ bài trên các trang</span>
          <span
            className={cn(
              "grid size-5 place-items-center rounded-full border",
              removePosts ? "border-lacquer bg-lacquer text-lacquer-ink" : "border-line",
            )}
            aria-hidden
          >
            {removePosts ? <Check className="size-3" /> : null}
          </span>
        </button>
        <Button type="submit" className="w-full">
          Lưu phòng đã chốt
        </Button>
      </form>
    </Modal>
  );
}
