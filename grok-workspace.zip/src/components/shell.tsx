import { useEffect, useState, type ReactNode } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import { CalendarDays, KeyRound, Megaphone } from "lucide-react";
import { ConfirmDialog } from "@/components/dialogs";
import { Button } from "@/components/ui";
import { useLedger } from "@/lib/ledger";
import { cn } from "@/lib/utils";

const NAV = [
  { to: "/", label: "Hôm nay", icon: CalendarDays, exact: true },
  { to: "/rooms", label: "Phòng", icon: KeyRound, exact: false },
  { to: "/pages", label: "Trang", icon: Megaphone, exact: false },
] as const;

function useReady() {
  const [ready, setReady] = useState(false);
  useEffect(() => {
    let alive = true;
    void Promise.resolve(useLedger.persist.rehydrate()).finally(() => {
      if (alive) setReady(true);
    });
    return () => {
      alive = false;
    };
  }, []);
  return ready;
}

function isActive(pathname: string, to: string, exact: boolean) {
  if (exact) return pathname === to;
  return pathname === to || pathname.startsWith(`${to}/`);
}

export function Shell({ children }: { children: ReactNode }) {
  const ready = useReady();
  const pathname = useRouterState({ select: (state) => state.location.pathname });
  const demo = useLedger((state) => state.demo);
  const clearAll = useLedger((state) => state.clearAll);
  const [confirm, setConfirm] = useState(false);

  return (
    <div className="min-h-dvh">
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-60 flex-col border-r border-line bg-surface px-4 py-6 md:flex">
        <div className="flex items-center gap-3 px-2">
          <span className="grid size-11 place-items-center rounded-2xl bg-lacquer text-lacquer-ink">
            <KeyRound className="size-5" aria-hidden />
          </span>
          <span>
            <span className="block font-display text-2xl leading-none">Sổ Sale</span>
            <span className="mt-1 block text-xs text-muted">Phòng đã chốt & trang đã đăng</span>
          </span>
        </div>
        <nav className="mt-8 flex flex-col gap-1">
          {NAV.map((item) => {
            const on = isActive(pathname, item.to, item.exact);
            const Icon = item.icon;
            return (
              <Link
                key={item.to}
                to={item.to}
                aria-current={on ? "page" : undefined}
                className={cn(
                  "flex min-h-11 items-center gap-3 rounded-2xl px-3 text-sm font-medium",
                  on ? "bg-lacquer text-lacquer-ink" : "text-muted",
                )}
              >
                <Icon className="size-5" aria-hidden />
                {item.label}
              </Link>
            );
          })}
        </nav>
        <p className="mt-auto px-2 text-xs text-muted">Dữ liệu nằm trên máy này.</p>
      </aside>

      <main className="md:pl-60">
        <div className="mx-auto w-full max-w-5xl px-4 pt-5 pb-28 md:px-8 md:pt-8 md:pb-12">
          <header className="mb-5 flex items-center gap-2 md:hidden">
            <span className="grid size-9 place-items-center rounded-xl bg-lacquer text-lacquer-ink">
              <KeyRound className="size-4" aria-hidden />
            </span>
            <span className="font-display text-xl">Sổ Sale</span>
          </header>
          {ready && demo ? (
            <div className="mb-4 flex flex-col gap-3 rounded-2xl bg-lacquer-soft px-4 py-3 sm:flex-row sm:items-center sm:justify-between">
              <p className="text-sm">
                Đang xem sổ mẫu ở Sài Gòn. Xóa hết khi bạn bắt đầu sổ thật.
              </p>
              <Button variant="quiet" onClick={() => setConfirm(true)} className="shrink-0">
                Xóa dữ liệu mẫu
              </Button>
            </div>
          ) : null}
          {ready ? children : <Boot />}
        </div>
      </main>

      <nav className="dock fixed inset-x-0 bottom-0 z-30 border-t border-line bg-surface md:hidden">
        <div className="grid grid-cols-3">
          {NAV.map((item) => {
            const on = isActive(pathname, item.to, item.exact);
            const Icon = item.icon;
            return (
              <Link
                key={item.to}
                to={item.to}
                aria-current={on ? "page" : undefined}
                className={cn(
                  "flex min-h-16 flex-col items-center justify-center gap-1 text-xs font-medium",
                  on ? "text-lacquer" : "text-muted",
                )}
              >
                <Icon className="size-5" aria-hidden />
                {item.label}
              </Link>
            );
          })}
        </div>
      </nav>

      <ConfirmDialog
        open={confirm}
        onOpenChange={setConfirm}
        title="Xóa toàn bộ sổ?"
        body="Phòng, trang và bài đăng đang có trên máy này sẽ mất. Không hoàn tác được."
        confirmLabel="Xóa hết"
        onConfirm={clearAll}
      />
    </div>
  );
}

function Boot() {
  return (
    <div>
      <p className="font-display text-4xl">Sổ Sale</p>
      <p className="mt-2 text-muted">Đang mở sổ phòng trọ…</p>
    </div>
  );
}
