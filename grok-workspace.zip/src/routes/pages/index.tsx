import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { PageCard } from "@/components/cards";
import { PageDialog } from "@/components/dialogs";
import { Button, EmptyState } from "@/components/ui";
import { fold } from "@/lib/format";
import { PLATFORMS, useLedger, type Platform } from "@/lib/ledger";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/pages/")({ component: PagesPage });

const CHIPS: { id: Platform | "all"; label: string }[] = [
  { id: "all", label: "Tất cả" },
  { id: "facebook", label: PLATFORMS.facebook },
  { id: "zalo", label: PLATFORMS.zalo },
  { id: "chotot", label: PLATFORMS.chotot },
  { id: "tiktok", label: PLATFORMS.tiktok },
  { id: "other", label: PLATFORMS.other },
];

function PagesPage() {
  const pages = useLedger((state) => state.pages);
  const posts = useLedger((state) => state.posts);
  const [platform, setPlatform] = useState<Platform | "all">("all");
  const [query, setQuery] = useState("");
  const [open, setOpen] = useState(false);

  const filtered = useMemo(() => {
    const needle = fold(query.trim());
    return pages
      .filter((page) => (platform === "all" ? true : page.platform === platform))
      .filter((page) => (needle ? fold(`${page.name} ${page.note}`).includes(needle) : true))
      .sort((a, b) => a.name.localeCompare(b.name, "vi"));
  }, [pages, platform, query]);

  return (
    <div>
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl md:text-4xl">Trang</h1>
          <p className="mt-1 text-sm text-muted">Nhóm và nền tảng bạn đã đăng bài.</p>
        </div>
        <Button onClick={() => setOpen(true)}>Thêm trang</Button>
      </div>

      <input
        className="mt-4 min-h-11 w-full rounded-xl bg-surface px-3 text-base shadow-card outline-none placeholder:text-muted"
        value={query}
        onChange={(event) => setQuery(event.target.value)}
        placeholder="Tìm tên nhóm…"
        aria-label="Tìm trang"
      />

      <div className="mt-3 flex flex-wrap gap-2">
        {CHIPS.map((chip) => (
          <button
            key={chip.id}
            type="button"
            aria-pressed={platform === chip.id}
            onClick={() => setPlatform(chip.id)}
            className={cn(
              "min-h-11 rounded-full px-4 text-sm font-medium",
              platform === chip.id ? "bg-lacquer text-lacquer-ink" : "bg-surface text-ink shadow-card",
            )}
          >
            {chip.label}
          </button>
        ))}
      </div>

      {pages.length === 0 ? (
        <div className="mt-6">
          <EmptyState
            title="Chưa có trang nào"
            body="Thêm nhóm Facebook, Zalo, Chợ Tốt hoặc TikTok để biết căn nào đã đăng ở đâu."
            action={<Button onClick={() => setOpen(true)}>Thêm trang đầu tiên</Button>}
          />
        </div>
      ) : filtered.length === 0 ? (
        <p className="mt-6 rounded-2xl bg-surface px-4 py-4 text-sm text-muted shadow-card">
          Không có trang khớp.
        </p>
      ) : (
        <div className="mt-4 grid gap-3 md:grid-cols-2">
          {filtered.map((page) => {
            const related = posts.filter((post) => post.pageId === page.id);
            const last = related.reduce((max, post) => (post.postedAt > max ? post.postedAt : max), "");
            return (
              <PageCard
                key={page.id}
                page={page}
                postCount={related.length}
                lastPosted={last || null}
              />
            );
          })}
        </div>
      )}

      <PageDialog open={open} onOpenChange={setOpen} />
    </div>
  );
}
