import { useMemo, useState } from "react";
import { Link, createFileRoute, useNavigate } from "@tanstack/react-router";
import { ChevronLeft, ExternalLink } from "lucide-react";
import { ConfirmDialog, PageDialog, PostDialog } from "@/components/dialogs";
import { Button, EmptyState } from "@/components/ui";
import { isUrl, relativeDay, todayISO } from "@/lib/format";
import { PLATFORMS, PLATFORM_MARK, useLedger } from "@/lib/ledger";

export const Route = createFileRoute("/pages/$pageId")({ component: PageDetail });

function PageDetail() {
  const { pageId } = Route.useParams();
  const navigate = useNavigate();
  const page = useLedger((state) => state.pages.find((item) => item.id === pageId));
  const rooms = useLedger((state) => state.rooms);
  const allPosts = useLedger((state) => state.posts);
  const posts = useMemo(
    () =>
      allPosts
        .filter((post) => post.pageId === pageId)
        .sort((a, b) => b.postedAt.localeCompare(a.postedAt)),
    [allPosts, pageId],
  );
  const setPostStatus = useLedger((state) => state.setPostStatus);
  const deletePage = useLedger((state) => state.deletePage);
  const [edit, setEdit] = useState(false);
  const [log, setLog] = useState(false);
  const [remove, setRemove] = useState(false);
  const today = todayISO();

  if (!page) {
    return (
      <EmptyState
        title="Không thấy trang này"
        body="Có thể trang đã bị xóa khỏi sổ."
        action={
          <Link
            to="/pages"
            className="inline-flex min-h-11 items-center rounded-full bg-lacquer px-4 text-sm font-medium text-lacquer-ink"
          >
            Về danh sách
          </Link>
        }
      />
    );
  }

  return (
    <div className="mx-auto max-w-3xl">
      <Link to="/pages" className="inline-flex min-h-11 items-center gap-1 text-sm font-medium text-muted">
        <ChevronLeft className="size-4" aria-hidden />
        Trang
      </Link>
      <div className="mt-3 flex items-start gap-3">
        <span className="grid size-12 shrink-0 place-items-center rounded-2xl bg-lacquer text-sm font-semibold text-lacquer-ink">
          {PLATFORM_MARK[page.platform]}
        </span>
        <div className="min-w-0">
          <p className="text-sm text-muted">{PLATFORMS[page.platform]}</p>
          <h1 className="font-display text-3xl break-words">{page.name}</h1>
        </div>
      </div>
      {page.note ? <p className="mt-3 text-sm text-muted">{page.note}</p> : null}
      {page.url && isUrl(page.url) ? (
        <a
          href={page.url}
          target="_blank"
          rel="noreferrer"
          className="mt-3 inline-flex min-h-11 items-center gap-2 text-sm font-medium text-lacquer"
        >
          Mở trang
          <ExternalLink className="size-4" aria-hidden />
        </a>
      ) : null}

      <div className="mt-5">
        <Button onClick={() => setLog(true)}>Ghi phòng đã đăng</Button>
      </div>

      <section className="mt-8">
        <h2 className="mb-3 font-display text-2xl">Phòng đã đăng ở đây</h2>
        {posts.length === 0 ? (
          <p className="rounded-2xl bg-surface px-4 py-4 text-sm text-muted shadow-card">
            Chưa ghi lần đăng nào lên trang này.
          </p>
        ) : (
          <ul className="rounded-2xl bg-surface px-4 shadow-card">
            {posts.map((post) => {
              const room = rooms.find((item) => item.id === post.roomId);
              if (!room) return null;
              return (
                <li
                  key={post.id}
                  className="flex items-center justify-between gap-3 border-b border-line py-3 last:border-0"
                >
                  <Link to="/rooms/$roomId" params={{ roomId: room.id }} className="min-w-0">
                    <span className="block truncate font-medium">{room.name}</span>
                    <span className="block text-sm text-muted">
                      {room.district} · {relativeDay(post.postedAt, today)}
                    </span>
                  </Link>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="shrink-0"
                    onClick={() => setPostStatus(post.id, post.status === "live" ? "removed" : "live")}
                  >
                    {post.status === "live" ? "Gỡ bài" : "Hiện lại"}
                  </Button>
                </li>
              );
            })}
          </ul>
        )}
      </section>

      <div className="mt-6 flex gap-2">
        <Button variant="quiet" onClick={() => setEdit(true)}>
          Sửa trang
        </Button>
        <Button variant="ghost" onClick={() => setRemove(true)}>
          Xóa
        </Button>
      </div>

      <PageDialog open={edit} onOpenChange={setEdit} page={page} />
      <PostDialog open={log} onOpenChange={setLog} pageId={page.id} />
      <ConfirmDialog
        open={remove}
        onOpenChange={setRemove}
        title="Xóa trang này?"
        body="Các lần đăng gắn với trang cũng bị xóa. Phòng trong sổ vẫn còn."
        confirmLabel="Xóa trang"
        onConfirm={() => {
          deletePage(page.id);
          void navigate({ to: "/pages" });
        }}
      />
    </div>
  );
}
