import { useState, type ReactNode } from "react";
import { Link, createFileRoute, useNavigate } from "@tanstack/react-router";
import { PageCard, RoomCard } from "@/components/cards";
import { PostDialog, RoomDialog } from "@/components/dialogs";
import { Badge, Button, EmptyState } from "@/components/ui";
import {
  formatDay,
  formatMonth,
  formatVnd,
  monthKey,
  relativeDay,
  todayISO,
} from "@/lib/format";
import { needsRepost, useLedger } from "@/lib/ledger";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const rooms = useLedger((state) => state.rooms);
  const pages = useLedger((state) => state.pages);
  const posts = useLedger((state) => state.posts);
  const setRoomFilter = useLedger((state) => state.setRoomFilter);
  const loadDemo = useLedger((state) => state.loadDemo);
  const navigate = useNavigate();
  const today = todayISO();
  const month = monthKey(today);
  const [roomOpen, setRoomOpen] = useState(false);
  const [log, setLog] = useState<{ open: boolean; roomId?: string }>({ open: false });

  const selling = rooms.filter((room) => room.status !== "closed");
  const closedMonth = rooms
    .filter((room) => room.status === "closed" && room.closedAt && monthKey(room.closedAt) === month)
    .sort((a, b) => (b.closedAt ?? "").localeCompare(a.closedAt ?? ""));
  const commission = closedMonth.reduce((sum, room) => sum + (room.commission ?? 0), 0);
  const postsToday = posts.filter((post) => post.postedAt === today).length;
  const attention = rooms
    .filter((room) => needsRepost(room, posts, today))
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  const recent = [...posts]
    .sort((a, b) => b.postedAt.localeCompare(a.postedAt) || b.id.localeCompare(a.id))
    .slice(0, 5);

  if (rooms.length === 0 && pages.length === 0) {
    return (
      <div className="mx-auto max-w-3xl">
        <p className="text-sm font-medium text-muted">Hôm nay</p>
        <h1 className="font-display text-3xl md:text-4xl">{formatDay(today)}</h1>
        <div className="mt-6">
          <EmptyState
            title="Sổ còn trống"
            body="Thêm phòng đang sale, ghi trang đã đăng, rồi chốt khi khách lấy phòng."
            action={
              <>
                <Button onClick={() => setRoomOpen(true)}>Thêm phòng</Button>
                <Button variant="quiet" onClick={loadDemo}>
                  Xem sổ mẫu
                </Button>
              </>
            }
          />
        </div>
        <RoomDialog open={roomOpen} onOpenChange={setRoomOpen} />
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-3xl">
      <p className="text-sm font-medium text-muted">Hôm nay · {formatMonth()}</p>
      <h1 className="mt-1 font-display text-3xl md:text-4xl">{formatDay(today)}</h1>

      <section className="mt-6 rounded-3xl bg-lacquer px-5 py-5 text-lacquer-ink">
        <p className="text-sm font-medium">Hoa hồng tháng này</p>
        <p className="mt-2 font-display text-4xl tabular-nums leading-none">{formatVnd(commission)}</p>
        <p className="mt-3 text-sm">
          {closedMonth.length
            ? `${closedMonth.length} phòng đã chốt`
            : "Chưa chốt phòng nào trong tháng"}
        </p>
      </section>

      <section className="mt-3 rounded-3xl bg-surface px-4 shadow-card">
        <LedgerRow label="Còn sale" value={String(selling.length)} />
        <LedgerRow label="Đã chốt tháng này" value={String(closedMonth.length)} />
        <LedgerRow label="Bài đăng hôm nay" value={String(postsToday)} />
      </section>

      <div className="mt-4 grid grid-cols-2 gap-2">
        <Button onClick={() => setLog({ open: true })}>Ghi bài đăng</Button>
        <Button variant="quiet" onClick={() => setRoomOpen(true)}>
          Thêm phòng
        </Button>
      </div>

      <section className="mt-8">
        <SectionTitle
          title="Nên đăng hôm nay"
          action={
            <Link
              to="/rooms"
              className="inline-flex min-h-11 items-center text-sm font-medium text-lacquer"
              onClick={() => setRoomFilter("selling")}
            >
              Phòng còn sale
            </Link>
          }
        />
        {attention.length === 0 ? (
          <p className="rounded-2xl bg-surface px-4 py-4 text-sm text-muted shadow-card">
            Các phòng đang sale đều đã được đăng trong 2 ngày qua.
          </p>
        ) : (
          <div className="grid gap-3">
            {attention.map((room) => (
              <RoomCard
                key={room.id}
                room={room}
                liveCount={posts.filter((post) => post.roomId === room.id && post.status === "live").length}
                onLog={() => setLog({ open: true, roomId: room.id })}
              />
            ))}
          </div>
        )}
      </section>

      <section className="mt-8">
        <SectionTitle
          title="Đã chốt tháng này"
          action={
            <button
              type="button"
              className="inline-flex min-h-11 items-center text-sm font-medium text-lacquer"
              onClick={() => {
                setRoomFilter("closed");
                void navigate({ to: "/rooms" });
              }}
            >
              Xem hết
            </button>
          }
        />
        {closedMonth.length === 0 ? (
          <p className="rounded-2xl bg-surface px-4 py-4 text-sm text-muted shadow-card">
            Tháng này chưa có phòng nào chốt.
          </p>
        ) : (
          <ul className="rounded-2xl bg-surface px-4 shadow-card">
            {closedMonth.map((room) => (
              <li key={room.id} className="border-b border-line last:border-0">
                <Link
                  to="/rooms/$roomId"
                  params={{ roomId: room.id }}
                  className="flex min-h-16 items-center justify-between gap-3 py-3"
                >
                  <span className="min-w-0">
                    <span className="block truncate font-medium">{room.name}</span>
                    <span className="block text-sm text-muted">
                      {room.district}
                      {room.closeNote ? ` · ${room.closeNote}` : ""}
                    </span>
                  </span>
                  <span className="shrink-0 text-right">
                    <span className="block font-display text-xl tabular-nums text-moss">
                      {formatVnd(room.commission ?? 0)}
                    </span>
                    <span className="block text-sm text-muted">
                      {room.closedAt ? relativeDay(room.closedAt, today) : ""}
                    </span>
                  </span>
                </Link>
              </li>
            ))}
          </ul>
        )}
      </section>

      <section className="mt-8">
        <SectionTitle
          title="Bài vừa đăng"
          action={
            <Link to="/pages" className="inline-flex min-h-11 items-center text-sm font-medium text-lacquer">
              Các trang
            </Link>
          }
        />
        {recent.length === 0 ? (
          <p className="rounded-2xl bg-surface px-4 py-4 text-sm text-muted shadow-card">
            Chưa ghi bài đăng nào.
          </p>
        ) : (
          <ul className="rounded-2xl bg-surface px-4 shadow-card">
            {recent.map((post) => {
              const room = rooms.find((item) => item.id === post.roomId);
              const page = pages.find((item) => item.id === post.pageId);
              if (!room || !page) return null;
              return (
                <li key={post.id} className="border-b border-line last:border-0">
                  <Link
                    to="/pages/$pageId"
                    params={{ pageId: page.id }}
                    className="flex min-h-16 items-center justify-between gap-3 py-3"
                  >
                    <span className="min-w-0">
                      <span className="block truncate font-medium">{room.name}</span>
                      <span className="block truncate text-sm text-muted">
                        {page.name} · {relativeDay(post.postedAt, today)}
                      </span>
                    </span>
                    <Badge tone={post.status === "live" ? "lacquer" : "muted"}>
                      {post.status === "live" ? "Đang hiện" : "Đã gỡ"}
                    </Badge>
                  </Link>
                </li>
              );
            })}
          </ul>
        )}
      </section>

      <RoomDialog open={roomOpen} onOpenChange={setRoomOpen} />
      <PostDialog
        open={log.open}
        onOpenChange={(open) => setLog((current) => ({ ...current, open }))}
        roomId={log.roomId}
      />
    </div>
  );
}

function LedgerRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between gap-3 border-b border-line py-3 last:border-0">
      <p className="text-sm text-muted">{label}</p>
      <p className="font-display text-2xl tabular-nums">{value}</p>
    </div>
  );
}

function SectionTitle({ title, action }: { title: string; action?: ReactNode }) {
  return (
    <div className="mb-3 flex flex-wrap items-end justify-between gap-x-3">
      <h2 className="font-display text-2xl">{title}</h2>
      {action}
    </div>
  );
}
