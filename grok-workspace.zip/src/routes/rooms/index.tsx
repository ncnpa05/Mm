import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { RoomCard } from "@/components/cards";
import { PostDialog, RoomDialog } from "@/components/dialogs";
import { Button, EmptyState } from "@/components/ui";
import { fold, formatVnd, monthKey, todayISO } from "@/lib/format";
import { useLedger, type RoomFilter } from "@/lib/ledger";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/rooms/")({ component: RoomsPage });

const CHIPS: { id: RoomFilter; label: string }[] = [
  { id: "all", label: "Tất cả" },
  { id: "selling", label: "Còn sale" },
  { id: "closed", label: "Đã chốt" },
];

function RoomsPage() {
  const rooms = useLedger((state) => state.rooms);
  const posts = useLedger((state) => state.posts);
  const filter = useLedger((state) => state.roomFilter);
  const setRoomFilter = useLedger((state) => state.setRoomFilter);
  const [query, setQuery] = useState("");
  const [roomOpen, setRoomOpen] = useState(false);
  const [logRoom, setLogRoom] = useState<string | null>(null);
  const today = todayISO();
  const month = monthKey(today);

  const filtered = useMemo(() => {
    const needle = fold(query.trim());
    return rooms
      .filter((room) => {
        if (filter === "selling" && room.status === "closed") return false;
        if (filter === "closed" && room.status !== "closed") return false;
        if (!needle) return true;
        return fold(
          `${room.name} ${room.district} ${room.address} ${room.landlordName} ${room.landlordPhone}`,
        ).includes(needle);
      })
      .sort((a, b) => {
        if (filter === "closed") return (b.closedAt ?? "").localeCompare(a.closedAt ?? "");
        return b.createdAt.localeCompare(a.createdAt);
      });
  }, [rooms, filter, query]);

  const closed = rooms.filter((room) => room.status === "closed");
  const monthSum = closed
    .filter((room) => room.closedAt && monthKey(room.closedAt) === month)
    .reduce((sum, room) => sum + (room.commission ?? 0), 0);
  const allSum = closed.reduce((sum, room) => sum + (room.commission ?? 0), 0);
  const counts: Record<RoomFilter, number> = {
    all: rooms.length,
    selling: rooms.filter((room) => room.status !== "closed").length,
    closed: closed.length,
  };

  return (
    <div>
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl md:text-4xl">Phòng</h1>
          <p className="mt-1 text-sm text-muted">Phòng đang sale và phòng đã chốt.</p>
        </div>
        <Button onClick={() => setRoomOpen(true)}>Thêm phòng</Button>
      </div>

      <input
        className="mt-4 min-h-11 w-full rounded-xl bg-surface px-3 text-base shadow-card outline-none placeholder:text-muted"
        value={query}
        onChange={(event) => setQuery(event.target.value)}
        placeholder="Tìm phòng, quận, chủ nhà…"
        aria-label="Tìm phòng"
      />

      <div className="mt-3 flex flex-wrap gap-2">
        {CHIPS.map((chip) => (
          <button
            key={chip.id}
            type="button"
            aria-pressed={filter === chip.id}
            onClick={() => setRoomFilter(chip.id)}
            className={cn(
              "min-h-11 rounded-full px-4 text-sm font-medium",
              filter === chip.id ? "bg-lacquer text-lacquer-ink" : "bg-surface text-ink shadow-card",
            )}
          >
            {chip.label} · {counts[chip.id]}
          </button>
        ))}
      </div>

      {filter === "closed" ? (
        <div className="mt-4 rounded-2xl bg-moss-soft px-4 py-4 text-moss">
          <p className="text-sm font-medium">Tổng hoa hồng đã chốt</p>
          <p className="mt-1 font-display text-3xl tabular-nums">{formatVnd(allSum)}</p>
          <p className="mt-1 text-sm">Tháng này {formatVnd(monthSum)}</p>
        </div>
      ) : null}

      {rooms.length === 0 ? (
        <div className="mt-6">
          <EmptyState
            title="Chưa có phòng"
            body="Thêm căn đang cần sale. Khi khách lấy phòng, bấm chốt để ghi hoa hồng."
            action={<Button onClick={() => setRoomOpen(true)}>Thêm phòng đầu tiên</Button>}
          />
        </div>
      ) : filtered.length === 0 ? (
        <p className="mt-6 rounded-2xl bg-surface px-4 py-4 text-sm text-muted shadow-card">
          Không có phòng khớp.
        </p>
      ) : (
        <div className="mt-4 grid gap-3 md:grid-cols-2">
          {filtered.map((room) => (
            <RoomCard
              key={room.id}
              room={room}
              liveCount={posts.filter((post) => post.roomId === room.id && post.status === "live").length}
              onLog={() => setLogRoom(room.id)}
            />
          ))}
        </div>
      )}

      <RoomDialog open={roomOpen} onOpenChange={setRoomOpen} />
      <PostDialog
        open={logRoom !== null}
        onOpenChange={(open) => {
          if (!open) setLogRoom(null);
        }}
        roomId={logRoom ?? undefined}
      />
    </div>
  );
}
