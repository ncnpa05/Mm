import { useMemo, useState } from "react";
import { Link, createFileRoute, useNavigate } from "@tanstack/react-router";
import { ChevronLeft, MapPin, Phone } from "lucide-react";
import { CloseDialog, ConfirmDialog, PostDialog, RoomDialog } from "@/components/dialogs";
import { Badge, Button, EmptyState, Modal, fieldClass } from "@/components/ui";
import { formatShort, formatVnd, isUrl, relativeDay, todayISO } from "@/lib/format";
import {
  ROOM_STATUS,
  ROOM_TYPES,
  listingText,
  useLedger,
  type RoomStatus,
} from "@/lib/ledger";

export const Route = createFileRoute("/rooms/$roomId")({ component: RoomPage });

function tone(status: RoomStatus): "lacquer" | "moss" | "ink" | "muted" {
  if (status === "closed") return "moss";
  if (status === "viewing") return "ink";
  if (status === "posted") return "muted";
  return "lacquer";
}

function RoomPage() {
  const { roomId } = Route.useParams();
  const navigate = useNavigate();
  const room = useLedger((state) => state.rooms.find((item) => item.id === roomId));
  const pages = useLedger((state) => state.pages);
  const allPosts = useLedger((state) => state.posts);
  const posts = useMemo(
    () =>
      allPosts
        .filter((post) => post.roomId === roomId)
        .sort((a, b) => b.postedAt.localeCompare(a.postedAt)),
    [allPosts, roomId],
  );
  const setStatus = useLedger((state) => state.setStatus);
  const setPostStatus = useLedger((state) => state.setPostStatus);
  const deleteRoom = useLedger((state) => state.deleteRoom);
  const reopenRoom = useLedger((state) => state.reopenRoom);
  const [edit, setEdit] = useState(false);
  const [log, setLog] = useState(false);
  const [close, setClose] = useState(false);
  const [remove, setRemove] = useState(false);
  const [reopen, setReopen] = useState(false);
  const [copied, setCopied] = useState(false);
  const [manual, setManual] = useState<string | null>(null);
  const today = todayISO();

  if (!room) {
    return (
      <EmptyState
        title="Không thấy phòng này"
        body="Có thể phòng đã bị xóa khỏi sổ."
        action={
          <Link
            to="/rooms"
            className="inline-flex min-h-11 items-center rounded-full bg-lacquer px-4 text-sm font-medium text-lacquer-ink"
          >
            Về danh sách
          </Link>
        }
      />
    );
  }

  const mapQuery = encodeURIComponent([room.address, room.district].filter(Boolean).join(", "));
  const phone = room.landlordPhone.replace(/[^\d+]/g, "");

  async function copyListing() {
    const text = listingText(room!);
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2000);
    } catch {
      setManual(text);
    }
  }

  return (
    <div className="mx-auto max-w-3xl">
      <Link to="/rooms" className="inline-flex min-h-11 items-center gap-1 text-sm font-medium text-muted">
        <ChevronLeft className="size-4" aria-hidden />
        Phòng
      </Link>
      <div className="mt-2 flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0">
          <Badge tone={tone(room.status)}>{ROOM_STATUS[room.status]}</Badge>
          <h1 className="mt-2 font-display text-3xl break-words md:text-4xl">{room.name}</h1>
          <p className="mt-1 text-muted">
            {room.district} · {ROOM_TYPES[room.type]}
            {room.areaM2 ? ` · ${room.areaM2}m²` : ""}
          </p>
        </div>
        <p className="font-display text-3xl tabular-nums">{formatVnd(room.price)}</p>
      </div>

      <div className="mt-5 grid gap-2">
        {room.landlordPhone ? (
          <a
            href={`tel:${phone}`}
            className="flex min-h-14 items-center justify-between gap-3 rounded-2xl bg-surface px-4 shadow-card"
          >
            <span>
              <span className="block text-sm text-muted">Chủ nhà</span>
              <span className="font-medium">
                {room.landlordName ? `${room.landlordName} · ` : ""}
                {room.landlordPhone}
              </span>
            </span>
            <Phone className="size-5 text-lacquer" aria-hidden />
          </a>
        ) : null}
        {room.address || room.district ? (
          <a
            href={`https://www.google.com/maps/search/?api=1&query=${mapQuery}`}
            target="_blank"
            rel="noreferrer"
            className="flex min-h-14 items-center justify-between gap-3 rounded-2xl bg-surface px-4 shadow-card"
          >
            <span className="min-w-0">
              <span className="block text-sm text-muted">Địa chỉ</span>
              <span className="block truncate font-medium">
                {room.address || room.district}
              </span>
            </span>
            <MapPin className="size-5 shrink-0 text-lacquer" aria-hidden />
          </a>
        ) : null}
      </div>

      {room.amenities.length ? (
        <div className="mt-4 flex flex-wrap gap-2">
          {room.amenities.map((item) => (
            <span key={item} className="rounded-full bg-surface px-3 py-2 text-sm shadow-card">
              {item}
            </span>
          ))}
        </div>
      ) : null}

      {room.notes ? <p className="mt-4 text-sm text-muted">{room.notes}</p> : null}

      {room.status === "closed" ? (
        <section className="mt-5 rounded-2xl bg-moss-soft px-4 py-4 text-moss">
          <p className="text-sm font-medium">Đã chốt {room.closedAt ? formatShort(room.closedAt) : ""}</p>
          <p className="mt-1 font-display text-3xl tabular-nums">{formatVnd(room.commission ?? 0)}</p>
          {room.closeNote ? <p className="mt-1 text-sm">{room.closeNote}</p> : null}
          <div className="mt-3 flex flex-wrap gap-2">
            <Button variant="quiet" onClick={() => setClose(true)}>
              Sửa lần chốt
            </Button>
            <Button variant="quiet" onClick={() => setReopen(true)}>
              Mở lại phòng
            </Button>
          </div>
        </section>
      ) : (
        <div className="mt-5 grid gap-2">
          <div className="grid grid-cols-3 gap-2">
            {(
              [
                ["open", "Còn sale"],
                ["posted", "Đã đăng"],
                ["viewing", "Đang xem"],
              ] as const
            ).map(([status, label]) => (
              <button
                key={status}
                type="button"
                aria-pressed={room.status === status}
                onClick={() => setStatus(room.id, status)}
                className={`min-h-11 rounded-full px-2 text-sm font-medium ${
                  room.status === status ? "bg-ink text-surface" : "bg-surface text-ink shadow-card"
                }`}
              >
                {label}
              </button>
            ))}
          </div>
          <div className="grid grid-cols-2 gap-2">
            <Button variant="quiet" onClick={() => void copyListing()}>
              {copied ? "Đã chép" : "Chép tin"}
            </Button>
            <Button variant="quiet" onClick={() => setLog(true)}>
              Ghi đã đăng
            </Button>
          </div>
          <Button onClick={() => setClose(true)}>Chốt sale</Button>
        </div>
      )}

      <section className="mt-8">
        <div className="mb-3 flex items-end justify-between gap-3">
          <h2 className="font-display text-2xl">Đã đăng ở đâu</h2>
          <Button variant="quiet" size="sm" onClick={() => setLog(true)}>
            Thêm
          </Button>
        </div>
        {posts.length === 0 ? (
          <p className="rounded-2xl bg-surface px-4 py-4 text-sm text-muted shadow-card">
            Chưa ghi trang nào cho phòng này.
          </p>
        ) : (
          <ul className="rounded-2xl bg-surface px-4 shadow-card">
            {posts.map((post) => {
              const page = pages.find((item) => item.id === post.pageId);
              if (!page) return null;
              return (
                <li key={post.id} className="border-b border-line py-3 last:border-0">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <Link to="/pages/$pageId" params={{ pageId: page.id }} className="font-medium">
                        {page.name}
                      </Link>
                      <p className="text-sm text-muted">{relativeDay(post.postedAt, today)}</p>
                      {isUrl(post.note) ? (
                        <a
                          href={post.note.trim()}
                          target="_blank"
                          rel="noreferrer"
                          className="text-sm font-medium text-lacquer"
                        >
                          Mở bài đăng
                        </a>
                      ) : post.note ? (
                        <p className="text-sm text-muted">{post.note}</p>
                      ) : null}
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setPostStatus(post.id, post.status === "live" ? "removed" : "live")}
                    >
                      {post.status === "live" ? "Gỡ bài" : "Đang hiện"}
                    </Button>
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </section>

      <div className="mt-6 flex gap-2">
        <Button variant="quiet" onClick={() => setEdit(true)}>
          Sửa phòng
        </Button>
        <Button variant="ghost" onClick={() => setRemove(true)}>
          Xóa
        </Button>
      </div>

      <RoomDialog open={edit} onOpenChange={setEdit} room={room} />
      <PostDialog open={log} onOpenChange={setLog} roomId={room.id} />
      <CloseDialog open={close} onOpenChange={setClose} room={room} />
      <ConfirmDialog
        open={remove}
        onOpenChange={setRemove}
        title="Xóa phòng này?"
        body="Các lần đăng của phòng cũng bị xóa khỏi sổ."
        confirmLabel="Xóa phòng"
        onConfirm={() => {
          deleteRoom(room.id);
          void navigate({ to: "/rooms" });
        }}
      />
      <ConfirmDialog
        open={reopen}
        onOpenChange={setReopen}
        title="Mở lại phòng?"
        body="Hoa hồng và ngày chốt sẽ được xóa. Bài đã gỡ không tự đăng lại."
        confirmLabel="Mở lại"
        onConfirm={() => reopenRoom(room.id)}
      />
      <Modal
        open={manual !== null}
        onOpenChange={(open) => {
          if (!open) setManual(null);
        }}
        title="Chép tin"
        description="Chọn toàn bộ đoạn dưới rồi sao chép."
      >
        <textarea readOnly className={`${fieldClass} min-h-48 py-2`} value={manual ?? ""} />
      </Modal>
    </div>
  );
}
