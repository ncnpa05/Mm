import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import { formatVnd, shiftISO, todayISO } from "@/lib/format";

export type RoomStatus = "open" | "posted" | "viewing" | "closed";
export type RoomType = "tro" | "ccmn" | "studio" | "house" | "shop";
export type Platform = "facebook" | "zalo" | "chotot" | "tiktok" | "other";
export type PostStatus = "live" | "removed";
export type RoomFilter = "all" | "selling" | "closed";

export const ROOM_STATUS: Record<RoomStatus, string> = {
  open: "Còn sale",
  posted: "Đã đăng",
  viewing: "Đang xem",
  closed: "Đã chốt",
};

export const ROOM_TYPES: Record<RoomType, string> = {
  tro: "Phòng trọ",
  ccmn: "CCMN",
  studio: "Studio",
  house: "Nguyên căn",
  shop: "Mặt bằng",
};

export const PLATFORMS: Record<Platform, string> = {
  facebook: "Facebook",
  zalo: "Zalo",
  chotot: "Chợ Tốt",
  tiktok: "TikTok",
  other: "Khác",
};

export const PLATFORM_MARK: Record<Platform, string> = {
  facebook: "Fb",
  zalo: "Zl",
  chotot: "CT",
  tiktok: "Tk",
  other: "Kh",
};

export const AMENITIES = [
  "Máy lạnh",
  "Gác lửng",
  "WC riêng",
  "Ban công",
  "Thang máy",
  "Chỗ để xe",
  "Nội thất",
  "Giờ giấc tự do",
] as const;

export interface Room {
  id: string;
  name: string;
  district: string;
  address: string;
  price: number;
  type: RoomType;
  areaM2: number | null;
  amenities: string[];
  landlordName: string;
  landlordPhone: string;
  status: RoomStatus;
  commission: number | null;
  closedAt: string | null;
  closeNote: string;
  notes: string;
  createdAt: string;
}

export interface RoomInput {
  name: string;
  district: string;
  address: string;
  price: number;
  type: RoomType;
  areaM2: number | null;
  amenities: string[];
  landlordName: string;
  landlordPhone: string;
  notes: string;
}

export interface Page {
  id: string;
  name: string;
  platform: Platform;
  url: string;
  note: string;
  createdAt: string;
}

export interface PageInput {
  name: string;
  platform: Platform;
  url: string;
  note: string;
}

export interface Post {
  id: string;
  roomId: string;
  pageId: string;
  postedAt: string;
  note: string;
  status: PostStatus;
}

interface LedgerData {
  rooms: Room[];
  pages: Page[];
  posts: Post[];
  demo: boolean;
}

interface LedgerState extends LedgerData {
  roomFilter: RoomFilter;
  addRoom: (input: RoomInput) => string;
  updateRoom: (id: string, input: RoomInput) => void;
  deleteRoom: (id: string) => void;
  setStatus: (id: string, status: Exclude<RoomStatus, "closed">) => void;
  closeRoom: (
    id: string,
    info: { commission: number; closedAt: string; closeNote: string; removePosts: boolean },
  ) => void;
  reopenRoom: (id: string) => void;
  addPage: (input: PageInput) => string;
  updatePage: (id: string, input: PageInput) => void;
  deletePage: (id: string) => void;
  logPosts: (input: { roomIds: string[]; pageIds: string[]; postedAt: string; note: string }) => void;
  setPostStatus: (id: string, status: PostStatus) => void;
  setRoomFilter: (filter: RoomFilter) => void;
  clearAll: () => void;
  loadDemo: () => void;
}

function uid(): string {
  return crypto.randomUUID();
}

function buildDemo(): LedgerData {
  const rooms: Room[] = [
    {
      id: "r-bachi",
      name: "Gác 20m² gần chợ Bà Chiểu",
      district: "Bình Thạnh",
      address: "214/12 Xô Viết Nghệ Tĩnh",
      price: 3_200_000,
      type: "tro",
      areaM2: 20,
      amenities: ["Máy lạnh", "Gác lửng", "WC riêng", "Chỗ để xe"],
      landlordName: "Chị Hạnh",
      landlordPhone: "0903 112 458",
      status: "posted",
      commission: null,
      closedAt: null,
      closeNote: "",
      notes: "Điện 3,8k, nước 100k/người, cọc 1 tháng.",
      createdAt: `${shiftISO(-8)}T02:00:00.000Z`,
    },
    {
      id: "r-q7",
      name: "CCMN full nội thất Lô A",
      district: "Quận 7",
      address: "88 Nguyễn Lương Bằng",
      price: 5_500_000,
      type: "ccmn",
      areaM2: 25,
      amenities: ["Máy lạnh", "Thang máy", "Nội thất", "Ban công"],
      landlordName: "Anh Khoa",
      landlordPhone: "0918 334 220",
      status: "viewing",
      commission: null,
      closedAt: null,
      closeNote: "",
      notes: "Khách nữ hẹn xem. Nội thất giữ nguyên.",
      createdAt: `${shiftISO(-6)}T02:00:00.000Z`,
    },
    {
      id: "r-thao",
      name: "Studio ban công Thảo Điền",
      district: "Thủ Đức",
      address: "12 Quốc Hương",
      price: 6_800_000,
      type: "studio",
      areaM2: 28,
      amenities: ["Máy lạnh", "Ban công", "Nội thất", "Thang máy"],
      landlordName: "Cô Mai",
      landlordPhone: "0988 221 903",
      status: "closed",
      commission: 1_500_000,
      closedAt: shiftISO(-2),
      closeNote: "Khách couple, vào cuối tháng",
      notes: "Hoa hồng một tháng tiền phòng.",
      createdAt: `${shiftISO(-12)}T02:00:00.000Z`,
    },
    {
      id: "r-govap",
      name: "Phòng không gác hẻm 45",
      district: "Gò Vấp",
      address: "45/8 Quang Trung",
      price: 2_400_000,
      type: "tro",
      areaM2: 16,
      amenities: ["WC riêng", "Chỗ để xe", "Giờ giấc tự do"],
      landlordName: "Chú Tư",
      landlordPhone: "0933 778 641",
      status: "open",
      commission: null,
      closedAt: null,
      closeNote: "",
      notes: "Không nuôi thú. Điện nước theo đồng hồ.",
      createdAt: `${shiftISO(-1)}T02:00:00.000Z`,
    },
    {
      id: "r-tanbinh",
      name: "Nguyên căn 2 phòng ngủ",
      district: "Tân Bình",
      address: "19 Hoàng Văn Thụ",
      price: 8_500_000,
      type: "house",
      areaM2: 48,
      amenities: ["Máy lạnh", "Chỗ để xe", "WC riêng"],
      landlordName: "Anh Dũng",
      landlordPhone: "0908 556 172",
      status: "closed",
      commission: 2_000_000,
      closedAt: shiftISO(-25),
      closeNote: "Gia đình 3 người, cọc 2 tháng",
      notes: "Hẻm xe hơi.",
      createdAt: `${shiftISO(-40)}T02:00:00.000Z`,
    },
    {
      id: "r-q10",
      name: "Mặt bằng mặt tiền nhỏ",
      district: "Quận 10",
      address: "102 Sư Vạn Hạnh",
      price: 12_000_000,
      type: "shop",
      areaM2: 30,
      amenities: ["WC riêng", "Chỗ để xe"],
      landlordName: "Chị Lan",
      landlordPhone: "0977 410 225",
      status: "posted",
      commission: null,
      closedAt: null,
      closeNote: "",
      notes: "Hợp quán nước, không karaoke.",
      createdAt: `${shiftISO(-5)}T02:00:00.000Z`,
    },
  ];

  const pages: Page[] = [
    {
      id: "p-fb-bt",
      name: "Hội phòng trọ Bình Thạnh",
      platform: "facebook",
      url: "",
      note: "Nhóm kín, đăng buổi sáng dễ có inbox.",
      createdAt: `${shiftISO(-20)}T02:00:00.000Z`,
    },
    {
      id: "p-fb-sg",
      name: "Nhà trọ Sài Gòn giá rẻ",
      platform: "facebook",
      url: "",
      note: "Nhóm lớn, nhớ kèm giá và quận ở dòng đầu.",
      createdAt: `${shiftISO(-18)}T02:00:00.000Z`,
    },
    {
      id: "p-chotot",
      name: "Chợ Tốt — Phòng trọ",
      platform: "chotot",
      url: "https://www.chotot.com",
      note: "",
      createdAt: `${shiftISO(-15)}T02:00:00.000Z`,
    },
    {
      id: "p-zalo",
      name: "Zalo khu Gò Vấp",
      platform: "zalo",
      url: "",
      note: "Nhóm chủ nhà quanh Quang Trung.",
      createdAt: `${shiftISO(-9)}T02:00:00.000Z`,
    },
    {
      id: "p-tiktok",
      name: "TikTok review phòng",
      platform: "tiktok",
      url: "",
      note: "Quay cửa và gác, gắn quận trong caption.",
      createdAt: `${shiftISO(-7)}T02:00:00.000Z`,
    },
  ];

  const posts: Post[] = [
    { id: "post-1", roomId: "r-bachi", pageId: "p-fb-bt", postedAt: todayISO(), note: "Đăng lúc sáng", status: "live" },
    { id: "post-2", roomId: "r-bachi", pageId: "p-fb-sg", postedAt: todayISO(), note: "", status: "live" },
    { id: "post-3", roomId: "r-q7", pageId: "p-fb-sg", postedAt: shiftISO(-1), note: "Kèm 4 ảnh", status: "live" },
    { id: "post-4", roomId: "r-q7", pageId: "p-chotot", postedAt: shiftISO(-1), note: "", status: "live" },
    { id: "post-5", roomId: "r-thao", pageId: "p-fb-sg", postedAt: shiftISO(-6), note: "", status: "removed" },
    { id: "post-6", roomId: "r-thao", pageId: "p-tiktok", postedAt: shiftISO(-5), note: "", status: "removed" },
    { id: "post-7", roomId: "r-tanbinh", pageId: "p-fb-bt", postedAt: shiftISO(-28), note: "", status: "removed" },
    { id: "post-8", roomId: "r-q10", pageId: "p-fb-sg", postedAt: shiftISO(-4), note: "", status: "live" },
    { id: "post-9", roomId: "r-q10", pageId: "p-chotot", postedAt: shiftISO(-4), note: "", status: "live" },
  ];

  return { rooms, pages, posts, demo: true };
}

export function listingText(room: Room): string {
  const lines = [`CHO THUÊ — ${room.name}`, `Khu vực: ${room.district}`];
  if (room.address) lines.push(`Địa chỉ: ${room.address}`);
  lines.push(`Giá: ${formatVnd(room.price)}/tháng`);
  lines.push(`Loại: ${ROOM_TYPES[room.type]}${room.areaM2 ? ` · ${room.areaM2}m²` : ""}`);
  if (room.amenities.length) lines.push(`Tiện ích: ${room.amenities.join(", ")}`);
  if (room.notes) lines.push(room.notes);
  if (room.landlordPhone) {
    const who = room.landlordName ? `${room.landlordName} — ` : "";
    lines.push(`Liên hệ: ${who}${room.landlordPhone}`);
  }
  return lines.join("\n");
}

export function needsRepost(room: Room, posts: Post[], today = todayISO()): boolean {
  if (room.status === "closed") return false;
  const live = posts.filter((post) => post.roomId === room.id && post.status === "live");
  if (live.length === 0) return true;
  const newest = live.reduce((max, post) => (post.postedAt > max ? post.postedAt : max), "");
  const [y, m, d] = newest.slice(0, 10).split("-").map(Number);
  const [ty, tm, td] = today.split("-").map(Number);
  if (!y || !m || !d || !ty || !tm || !td) return true;
  const age = Math.round((Date.UTC(ty, tm - 1, td) - Date.UTC(y, m - 1, d)) / 86_400_000);
  return age >= 2;
}

const emptyData: LedgerData = { rooms: [], pages: [], posts: [], demo: false };

export const useLedger = create<LedgerState>()(
  persist(
    (set) => ({
      ...buildDemo(),
      roomFilter: "all",
      addRoom: (input) => {
        const id = uid();
        const room: Room = {
          ...input,
          id,
          status: "open",
          commission: null,
          closedAt: null,
          closeNote: "",
          createdAt: new Date().toISOString(),
        };
        set((state) => ({ rooms: [room, ...state.rooms] }));
        return id;
      },
      updateRoom: (id, input) =>
        set((state) => ({
          rooms: state.rooms.map((room) => (room.id === id ? { ...room, ...input } : room)),
        })),
      deleteRoom: (id) =>
        set((state) => ({
          rooms: state.rooms.filter((room) => room.id !== id),
          posts: state.posts.filter((post) => post.roomId !== id),
        })),
      setStatus: (id, status) =>
        set((state) => ({
          rooms: state.rooms.map((room) =>
            room.id === id
              ? { ...room, status, commission: null, closedAt: null, closeNote: "" }
              : room,
          ),
        })),
      closeRoom: (id, info) =>
        set((state) => ({
          rooms: state.rooms.map((room) =>
            room.id === id
              ? {
                  ...room,
                  status: "closed",
                  commission: info.commission,
                  closedAt: info.closedAt,
                  closeNote: info.closeNote,
                }
              : room,
          ),
          posts: info.removePosts
            ? state.posts.map((post) =>
                post.roomId === id ? { ...post, status: "removed" } : post,
              )
            : state.posts,
        })),
      reopenRoom: (id) =>
        set((state) => ({
          rooms: state.rooms.map((room) =>
            room.id === id
              ? { ...room, status: "open", commission: null, closedAt: null, closeNote: "" }
              : room,
          ),
        })),
      addPage: (input) => {
        const id = uid();
        const page: Page = { ...input, id, createdAt: new Date().toISOString() };
        set((state) => ({ pages: [page, ...state.pages] }));
        return id;
      },
      updatePage: (id, input) =>
        set((state) => ({
          pages: state.pages.map((page) => (page.id === id ? { ...page, ...input } : page)),
        })),
      deletePage: (id) =>
        set((state) => ({
          pages: state.pages.filter((page) => page.id !== id),
          posts: state.posts.filter((post) => post.pageId !== id),
        })),
      logPosts: (input) =>
        set((state) => {
          const posts = state.posts.map((post) => ({ ...post }));
          for (const roomId of input.roomIds) {
            for (const pageId of input.pageIds) {
              const existing = posts.find(
                (post) =>
                  post.roomId === roomId && post.pageId === pageId && post.postedAt === input.postedAt,
              );
              if (existing) {
                existing.note = input.note || existing.note;
                existing.status = "live";
              } else {
                posts.push({
                  id: uid(),
                  roomId,
                  pageId,
                  postedAt: input.postedAt,
                  note: input.note,
                  status: "live",
                });
              }
            }
          }
          const chosen = new Set(input.roomIds);
          return {
            posts,
            rooms: state.rooms.map((room) =>
              chosen.has(room.id) && room.status === "open" ? { ...room, status: "posted" } : room,
            ),
          };
        }),
      setPostStatus: (id, status) =>
        set((state) => ({
          posts: state.posts.map((post) => (post.id === id ? { ...post, status } : post)),
        })),
      setRoomFilter: (roomFilter) => set({ roomFilter }),
      clearAll: () => set(emptyData),
      loadDemo: () => set(buildDemo()),
    }),
    {
      name: "so-sale-v1",
      skipHydration: true,
      storage: createJSONStorage(() => localStorage),
      partialize: (state) => ({
        rooms: state.rooms,
        pages: state.pages,
        posts: state.posts,
        demo: state.demo,
      }),
    },
  ),
);
