export function todayISO(now = new Date()): string {
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, "0");
  const d = String(now.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}

export function shiftISO(days: number, now = new Date()): string {
  const next = new Date(now);
  next.setDate(next.getDate() + days);
  return todayISO(next);
}

export function monthKey(iso: string): string {
  return iso.slice(0, 7);
}

export function daysSince(iso: string, today = todayISO()): number {
  const [y, m, d] = iso.slice(0, 10).split("-").map(Number);
  const [ty, tm, td] = today.slice(0, 10).split("-").map(Number);
  if (!y || !m || !d || !ty || !tm || !td) return 0;
  const a = Date.UTC(y, m - 1, d);
  const b = Date.UTC(ty, tm - 1, td);
  return Math.round((b - a) / 86_400_000);
}

function cap(text: string): string {
  return text ? text.charAt(0).toUpperCase() + text.slice(1) : text;
}

export function formatDay(iso: string): string {
  const [y, m, d] = iso.slice(0, 10).split("-").map(Number);
  if (!y || !m || !d) return iso;
  return cap(
    new Intl.DateTimeFormat("vi-VN", {
      weekday: "long",
      day: "numeric",
      month: "long",
    }).format(new Date(y, m - 1, d)),
  );
}

export function formatShort(iso: string): string {
  const [y, m, d] = iso.slice(0, 10).split("-").map(Number);
  if (!y || !m || !d) return iso;
  return new Intl.DateTimeFormat("vi-VN", { day: "numeric", month: "short" }).format(
    new Date(y, m - 1, d),
  );
}

export function formatMonth(now = new Date()): string {
  return cap(new Intl.DateTimeFormat("vi-VN", { month: "long", year: "numeric" }).format(now));
}

export function relativeDay(iso: string, today = todayISO()): string {
  const days = daysSince(iso, today);
  if (days === 0) return "Hôm nay";
  if (days === 1) return "Hôm qua";
  if (days > 1 && days < 7) return `${days} ngày trước`;
  return formatShort(iso);
}

export function formatVnd(amount: number): string {
  if (!Number.isFinite(amount) || amount === 0) return "0đ";
  if (amount < 1_000_000) return `${Math.round(amount).toLocaleString("vi-VN")}đ`;
  const rounded = Math.round((amount / 1_000_000) * 10) / 10;
  const text = rounded.toLocaleString("vi-VN", {
    minimumFractionDigits: Number.isInteger(rounded) ? 0 : 1,
    maximumFractionDigits: 1,
  });
  return `${text} triệu`;
}

export function trieuInput(vnd: number | null): string {
  if (vnd == null || vnd === 0) return "";
  const rounded = Math.round((vnd / 1_000_000) * 10) / 10;
  return rounded.toLocaleString("vi-VN", { maximumFractionDigits: 1 });
}

export function fold(value: string): string {
  return value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/đ/g, "d")
    .replace(/Đ/g, "d")
    .toLowerCase();
}

export function isUrl(value: string): boolean {
  return /^https?:\/\//i.test(value.trim());
}
